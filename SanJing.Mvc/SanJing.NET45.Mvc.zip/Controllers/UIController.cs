﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class UIController : Controller
    {
        /// <summary>
        /// CMS
        /// </summary>
        /// <returns></returns>
        public ActionResult Cms()
        {
            return Redirect("/ui/cms/index.html");
        }
        /// <summary>
        /// APP
        /// </summary>
        /// <returns></returns>
        public ActionResult App()
        {
            return Redirect("/ui/app/index.html");
        }
        /// <summary>
        /// 原型
        /// </summary>
        /// <returns></returns>
        public ActionResult Logic()
        {
            return Redirect("/ui/logic/index.html");
        }
    }
}