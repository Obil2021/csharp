﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using static $safeprojectname$.Models.cms.AccountModel;

namespace $safeprojectname$.Controllers.apis.cms
{
    /// <summary>
    /// 当前登陆账户相关
    /// </summary>
    [RoutePrefix("api/cms/Account")]
    public class AccountController : ApiController
    {
        /// <summary>
        /// 账户登陆
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [HttpOptions]
        [Route("Login")]
        [SwaggerVersion(1.0, "2020-01-01")]
        public WebApiResult<LoginRes> Login([FromBody]LoginReq req)
        {
            using (var res = new WebApiResultBuilder<LoginRes>())
            {
                res.data.Token = WebApiAuthConfig.GetUserToken("1", this);
                return res.Successed();
            }
        }
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [HttpOptions]
        [Route("EditPassword")]
        [WebApiAuthorizationFilter("123")]
        [SwaggerVersion(1.0, "2020-01-01")]
        public WebApiResult<WebApiResultEmpty> EditPassword([FromBody]EditPasswordReq req)
        {
            using (var res = new WebApiResultBuilder<WebApiResultEmpty>())
            {
                return res.Successed();
            }
        }
        [HttpPost]
        [HttpOptions]
        [Route("SignTest")]
        [WebApiAuthorizationFilter("123")]
        [SwaggerVersion(1.0, "2020-01-01")]
        public WebApiResult<WebApiResultEmpty> SignTest([FromBody]WebApiSignRequest req)
        {
            using (var res = new WebApiResultBuilder<WebApiResultEmpty>())
            {
                return res.Successed();
            }
        }
    }
}
