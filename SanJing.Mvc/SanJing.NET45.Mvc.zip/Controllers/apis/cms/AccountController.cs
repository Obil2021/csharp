﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using static $safeprojectname$.Models.cms.AccountModel;

namespace $safeprojectname$.Controllers.apis.cms
{
    /// <summary>
    /// 当前登陆账户相关
    /// </summary>
    [RoutePrefix("api/cms/Account")]
    public class AccountController : ApiController
    {
        /// <summary>
        /// 账户登陆
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [HttpOptions]
        [Route("Login")]
        [SwaggerVersion(1.0, "2020-01-01")]
        public WebApiResult<LoginRes> Login([FromBody]LoginReq req)
        {
            using (var res = new WebApiResultBuilder<LoginRes>())
            {
                return res.Successed();
            }
        }
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        [HttpPost]
        [HttpOptions]
        [Route("EditPassword")]
        [WebApiAuthorizationFilter]
        [SwaggerVersion(1.0, "2020-01-01")]
        public WebApiResult<WebApiResultEmpty> EditPassword([FromBody]EditPasswordReq req)
        {
            using (var res = new WebApiResultBuilder<WebApiResultEmpty>())
            {
                string userid = User.Identity.Name;
                return res.Successed();
            }
        }
    }
}
