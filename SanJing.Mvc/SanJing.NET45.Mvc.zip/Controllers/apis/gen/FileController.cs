﻿using SanJing.Hash;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Configuration;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.Web.Http;
using static $safeprojectname$.Models.gen.FileModel;

namespace $safeprojectname$.Controllers.apis.gen
{
    /// <summary>
    /// 文件上传
    /// </summary>
    [RoutePrefix("api/gen/File")]
    public class FileController : ApiController
    {

        /// <summary>
        /// 单个上传
        /// .jpg|.jpeg|.png|.gif|.doc|.docx|.xls|.xlsx|.pdf
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [HttpOptions]
        [Route("Upload")]
        [SwaggerOperation(SwaggerOperationId.FILE_UPLOAD)]
        [SwaggerVersion(1.0, "2020-01-01")]
        public async Task<WebApiResult<UploadRes>> UploadAsync()
        {
            using (var res = new WebApiResultBuilder<UploadRes>())
            {
                var path = "/content/uploads";
                var root = HostingEnvironment.MapPath(path);
                Directory.CreateDirectory(root);
                var provider = new MultipartFormDataStreamProvider(root);
                
                await Request.Content.ReadAsMultipartAsync(provider);
                if (provider.FileData.Count > 0)
                {
                    var file = provider.FileData[0];
                    try
                    {
                        var fileName = file.Headers.ContentDisposition.FileName.Trim('"');
                        var fileExtensionName = Path.GetExtension(fileName).ToLower();
                        var fileExtensionNames = ConfigurationManager.AppSettings["UploadFileExtensionName"];
                        if (fileExtensionNames?.Contains(fileExtensionName) != true)
                            return res.Error1400($"不支持的文件格式({fileExtensionName}):{fileExtensionNames ?? "没有相关配置"}");


                        await Task.Run(() =>
                        {
                            var fileInfo = new FileInfo(file.LocalFileName);
                            var fileMD5 = Guid.NewGuid().ToString("N");
                            using (var fileStream = fileInfo.OpenRead())
                            {
                                fileMD5 = Encrypt.MD5(fileStream).ToLower();
                            }
                            fileName = $"{fileMD5}{ fileExtensionName}";
                            var fileFullName = $"{root}/{fileName}";
                            if (File.Exists(fileFullName))
                                fileInfo.Delete();
                            else
                                fileInfo.MoveTo(fileFullName);
                        });

                        res.data.FileId = $"{path}/{fileName}";
                        res.data.FileUrl = $"{Request.RequestUri.GetLeftPart(UriPartial.Authority)}{path}/{fileName}";
                        return res.Successed();
                    }
                    catch (Exception ex)
                    {
                        NLog.LogManager.GetCurrentClassLogger().Error(ex);
                        await Task.Run(() => new FileInfo(file.LocalFileName).Delete());
                        return res.Error1400($"上传失败:{ex.Message?.Trim() ?? "未知"}");
                    }
                }
                return res.Error1400("请选择文件");
            }
        }
    }
}
