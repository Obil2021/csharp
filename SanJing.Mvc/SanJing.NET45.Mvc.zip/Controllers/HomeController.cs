﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using NLog;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// 接口
        /// </summary>
        /// <returns></returns>
        public ActionResult Swagger()
        {
            return  Redirect("/swagger");
        }
        /// <summary>
        /// 日志
        /// </summary>
        /// <returns></returns>
        public ActionResult NLog()
        {
            LogManager.GetCurrentClassLogger().Info(Request.Url.AbsoluteUri);
            return Redirect($"/content/logs/{DateTime.Today:yyyy-MM-dd}.log");
        }
    }
}