﻿$(document).ready(function () {
    $('.resource > .heading .options').each(function (i, r) {
        $(r).children().each(function (j, ul) {
            if (j == 1) {
                $(ul).hide();
            }
        });
       // URL(i, r);
    });
});

//function URL(index, ele) {
//    $('.resource > .endpoints .heading h3').each(function (j, n) {
//        if (j == index) {
//            $(n).children().each(function (u, ul) {
//                if (u == 1) {
//                    var apiurl = $(ul).find('a').text();
//                    $(ele).append("<li><a href=\"" + apiurl + "\">URL</a></li>");
//                    return;
//                }
//            });
//        }
//    });
//}