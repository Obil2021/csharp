﻿using SanJing.Hash;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Caching;
using System.Web;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    public class WebApiSignRequestConfig
    {
        public static object lockObject { get; set; } = 0;
        public static bool ValidSignature(TWebApiSignRequest signature, string uri, ModelStateDictionary modelState)
        {
            var date = new DateTime(1970, 1, 1, 0, 0, 0).AddSeconds(Convert.ToDouble(signature.sTimestamp));
            var datemin = date.AddMinutes(-5);
            var datemax = date.AddMinutes(5);
            //时间戳比较 ,前后10分钟之内
            if (DateTime.Now < datemin || DateTime.Now > datemax)
            {
                modelState.AddModelError(nameof(signature.sTimestamp), "sTimestamp 无效");
                return false;
            }

            //小s开头表示需要签名
            var signs = signature.GetType().GetProperties().Where(q => q.Name.StartsWith("s"))
                .Select(q => $"{q.Name}={q.GetValue(signature)}").ToArray();
            var sign = string.Join("&", signs);
            var result = string.Compare(Encrypt.MD5(sign), signature.Sign, true) == 0;
            if (result)
            {
                //验证随机字符串是否已使用
                lock (lockObject)
                {
                    var requestId = Encrypt.MD5($"{signature.sRandomStr}@{uri}");
                    if (MemoryCache.Default.Contains(requestId))
                    {
                        modelState.AddModelError(nameof(signature.sRandomStr), "sRandomStr 无效");
                        return false;
                    }
                    else
                        MemoryCache.Default.Set(requestId, 0, DateTime.Now.AddMinutes(1));//1分钟
                }
            }
            else
                modelState.AddModelError(nameof(signature.Sign), "Sign 签名错误");

            return result;
        }
    }
    public interface TWebApiSignRequest
    {
        decimal sTimestamp { get; set; }
        string sRandomStr { get; set; }
        string Sign { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class WebApiSignRequest : TWebApiSignRequest
    {
        /// <summary>
        /// 时间戳
        /// </summary>
        [Range(typeof(decimal), "946656000", "4070880000", ErrorMessage = WebApiConfig.RANGE_MSG)]
        public decimal sTimestamp { get; set; }
        /// <summary>
        /// 随机字符串
        /// </summary>
        [Required(ErrorMessage = WebApiConfig.REQUIRED_MSG)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = WebApiConfig.STRINGLENGTH_MSG)]
        [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = WebApiConfig.REGULAR_NUM_ABC_MSG)]
        public string sRandomStr { get; set; }
        /// <summary>
        /// 签名
        /// </summary>
        [Required(ErrorMessage = WebApiConfig.REQUIRED_MSG)]
        [StringLength(32, MinimumLength = 32, ErrorMessage = WebApiConfig.STRINGLENGTH_MSG)]
        [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = WebApiConfig.REGULAR_NUM_ABC_MSG)]
        public string Sign { get; set; }
    }
}