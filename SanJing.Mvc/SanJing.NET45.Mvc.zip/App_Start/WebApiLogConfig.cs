﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    public class WebApiLogConfig
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="log"></param>
        public static void SaveAs(WebApiActionExecutedLogModel log)
        {
            //存储日志
        }
    }
    public class WebApiActionExecutedLogModel
    {
        public string UserName { get; set; }
        public string AbsolutePath { get; set; } = "0.0.0.0";
        public string Method { get; set; }
        public string UserIPAddress { get; set; }
        public Dictionary<string, object> ActionArguments { get; set; }
        public object ResultContent { get; set; }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}