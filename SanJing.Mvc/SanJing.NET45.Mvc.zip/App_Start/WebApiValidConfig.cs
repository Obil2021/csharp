﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// 验证
    /// </summary>
    public class WebApiValidConfig
    {
        /// <summary>
        /// 数据库实体是否存在验证
        /// </summary>
        /// <param name="value">值</param>
        /// <param name="table">表名</param>
        /// <param name="field">字段</param>
        /// <returns></returns>
        public static bool DbEntityExist(string value, string table, string field)
        {
            string sql = $"SELECT [{field}] FROM [{table}] WHERE {field} = '{value}'";
            return true;
        }
    }
    /// <summary>
    /// 模型数据库尸体验证
    /// </summary>
    public class DbModelValidAttribute : Attribute
    {
        /// <summary>
        /// 标识名称
        /// </summary>
        public string FieldName { get; set; } = "Id";
        /// <summary>
        /// 表明
        /// </summary>
        public string TableName { get; set; }
        /// <summary>
        /// 错误信息
        /// </summary>
        public string ErrorMessage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName">表名称</param>
        /// <param name="errorMessage">错误消息</param>

        public DbModelValidAttribute(string tableName, string errorMessage = "不存在")
        {
            TableName = tableName;
            ErrorMessage = errorMessage;
        }
    }
    /// <summary>
    /// 控制器参数数据库实体验证
    /// </summary>
    public class DbActionValidAttribute : DbModelValidAttribute
    {
        /// <summary>
        /// 参数名
        /// </summary>
        public string ArgName { get; set; }
        /// <summary>
        /// 实例化
        /// </summary>
        /// <param name="argName">参数名</param>
        /// <param name="tableName">表名称</param>
        /// <param name="errorMessage">错误消息</param>
        public DbActionValidAttribute(string argName, string tableName, string errorMessage = "不存在") :
            base(tableName, errorMessage)
        {
            ArgName = argName;
        }
    }
}