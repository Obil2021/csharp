﻿using SanJing.Hash;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Caching;
using System.Security.Principal;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    public class WebApiAuthConfig
    {
        /// <summary>
        /// 获取用户ID
        /// </summary>
        /// <param name="token"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public static bool TryGetUserId(string token, out string userId)
        {
            try
            {
                var data = Decrypt.AES128(HttpUtility.UrlDecode(token));
                userId = HttpUtility.UrlDecode(data.Split('&')[1]);
                var expire = long.Parse(data.Split('&')[0]);
                return expire >= DateTime.Now.Ticks && TryGetUserIdExtansion(userId);
            }
            catch { userId = string.Empty; return false; }
        }
        /// <summary>
        /// 获取token值
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="token">需要删掉的Token</param>
        /// <returns></returns>
        public static string GetUserToken(string userId, ApiController api)
        {
            var token = Encrypt.AES128($"{DateTime.Now.AddDays(7).Ticks}&{HttpUtility.UrlEncode(userId)}");
            token = HttpUtility.UrlEncode(token);
            GetUserTokenExtansion(token);
            var identity = api.User.Identity as WebApiAuthIdentity;
            identity.Name = userId;
            identity.Token = token;
            identity.SaveCookie = true;
            return token;
        }
        /// <summary>
        /// 获取用户ID（扩展验证）
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private static bool TryGetUserIdExtansion(string userId)
        {
            //这里可以做其他验证，例如数据库查询
            return true;
        }
        /// <summary>
        /// 获取token值(扩展处理)
        /// </summary>
        /// <param name="token"></param>
        private static void GetUserTokenExtansion(string token)
        {
            //这里可以做其他操作，例如数据库存储
        }
        /// <summary>
        /// 权限验证
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="authCode"></param>
        /// <returns></returns>
        public static bool HasAuth(string userId, string authCode)
        {
            return true;
        }
    }

    public class WebApiAuthPrincipal : IPrincipal
    {
        public IIdentity Identity { get; set; }
        public bool IsInRole(string role)
        {
            return WebApiAuthConfig.HasAuth(Identity.Name, role);
        }
    }
    public class WebApiAuthIdentity : IIdentity
    {
        public WebApiAuthIdentity(string name)
        {
            Name = name;
        }
        public string Name { get; set; }

        public string AuthenticationType { get; private set; } = "Token";

        public bool IsAuthenticated { get { return !string.IsNullOrWhiteSpace(Name); } }

        public string Token { get; set; }
        public bool SaveCookie { get; set; }
    }
}