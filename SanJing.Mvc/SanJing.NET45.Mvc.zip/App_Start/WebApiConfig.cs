﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using SanJing.Hash;
using $safeprojectname$;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Runtime.Caching;
using System.ServiceModel.Channels;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    public static class WebApiConfig
    {
        /// <summary>
        /// 数字或账号组成
        /// </summary>
        public const string REGULAR_NUM_ABC = "^[A-Za-z0-9]+$";
        public const string REGULAR_NUM_ABC_MSG = "{0} 必须由字符或数字组成";
        /// <summary>
        /// 数字组成
        /// </summary>
        public const string REGULAR_NUM = "^[0-9]*$";
        /// <summary>
        /// 邮箱
        /// </summary>
        public const string REGULAR_EMAIL = @"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
        /// <summary>
        /// 身份证
        /// </summary>
        public const string REGULAR_IDCARD = @"^\d{15}|\d{18}$";
        /// <summary>
        /// 日期
        /// </summary>
        public const string REGULAR_DATE = @"^\d{4}-\d{1,2}-\d{1,2}";

        public const string STRINGLENGTH_MSG = "{0} 长度必须在{1}和{2}之间";
        public const string RANGE_MSG = "{0} 值必须在{1}和{2}之间";
        public const string REQUIRED_MSG = "{0} 不能为空";

        public static void Register(HttpConfiguration config)
        {
            // Web API 配置和服务

            // Web API 路由
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            //异常处理
            config.Filters.Add(new WebApiExceptionFilterAttribute());
            //过滤器
            config.Filters.Add(new WebApiActionFilterAttribute());

            // 移除XML序列化器
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            // 解决json序列化时的循环引用问题
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            // json日期格式
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatHandling = DateFormatHandling.MicrosoftDateFormat;
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm:ss";
            //json 空对象处理
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new WebApiJsonContractResolver();
        }
    }
    public class WebApiJsonContractResolver : DefaultContractResolver
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="memberSerialization"></param>
        /// <returns></returns>
        protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
        {
            return type.GetProperties()
                   .Select(p =>
                   {


                       var jp = base.CreateProperty(p, memberSerialization);

                       var CustomAttributes = p.GetCustomAttributes(true);

                       jp.ValueProvider = new JsonDefaultValueProvider(p);//默认值

                       if (CustomAttributes != null && CustomAttributes.Any(q => q is JsonDateTimeFormat))
                       {
                           var dateTimeFormat = CustomAttributes.First(q => q is JsonDateTimeFormat) as JsonDateTimeFormat;
                           jp.Converter = new IsoDateTimeConverter() { DateTimeFormat = dateTimeFormat.Format };//日期格式化
                       }
                       return jp;
                   }).ToList();
        }
    }
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDateTimeFormat : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="format"></param>
        public JsonDateTimeFormat(string format)
        {
            Format = format;
        }
    }
    public class JsonDefaultValueProvider : IValueProvider
    {
        private PropertyInfo _MemberInfo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="memberInfo"></param>
        /// <param name="value"></param>
        public JsonDefaultValueProvider(PropertyInfo memberInfo)
        {
            _MemberInfo = memberInfo;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public object GetValue(object target)
        {
            object result = _MemberInfo.GetValue(target, null);
            if (result == null)
            {
                if (_MemberInfo.PropertyType == typeof(string))
                    return string.Empty;
                if (_MemberInfo.PropertyType.IsArray)
                    return Array.CreateInstance(_MemberInfo.PropertyType.GetElementType(), 0);
                if (_MemberInfo.PropertyType.GetConstructor(Type.EmptyTypes) != null)
                    return Activator.CreateInstance(_MemberInfo.PropertyType);
            }
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>

        public void SetValue(object target, object value)
        {
            _MemberInfo.SetValue(target, value, null);
        }
    }
    public class WebApiAuthorizationFilterAttribute : AuthorizationFilterAttribute
    {
        /// <summary>
        /// 权限代码
        /// </summary>
        private string AuthCode { get; set; }
        /// <summary>
        /// 并发，当为False时不能并发请求，默认为False
        /// </summary>
        public bool Concurrency { get; set; }

        public WebApiAuthorizationFilterAttribute() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authCodes">权限代码</param>
        public WebApiAuthorizationFilterAttribute(string authCode)
        {
            AuthCode = authCode;
        }
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //OPTIONS
            if (actionContext.Request.Method == HttpMethod.Options)
                actionContext.Request.CreateResponse(HttpStatusCode.Accepted);
            else if (!actionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any())
            {
                //身份验证
                if (!actionContext.Request.Headers.TryGetValues(ConfigurationManager.AppSettings["AuthHeaderName"], out IEnumerable<string> tokens))
                {
                    var token = actionContext.Request.Headers.GetCookies(ConfigurationManager.AppSettings["AuthHeaderName"])
                        .FirstOrDefault()?.Cookies?.FirstOrDefault()?.Value;
                    AuthValid(actionContext, token, Concurrency);
                }
                else
                {
                    string token = tokens?.FirstOrDefault() ?? string.Empty;
                    AuthValid(actionContext, token, Concurrency);
                }
            }

            base.OnAuthorization(actionContext);
        }
        private static object lockObject { get; set; } = 0;
        private void AuthValid(HttpActionContext actionContext, string token, bool concurrency)
        {
            if (string.IsNullOrWhiteSpace(token) || !WebApiAuthConfig.TryGetUserId(token, out string userId))
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1401());
            else
            {
                var api = actionContext.ControllerContext.Controller as ApiController;
                api.User = new WebApiAuthPrincipal() { Identity = new WebApiAuthIdentity(userId) { Token = token } };
                if (!string.IsNullOrWhiteSpace(AuthCode) && !api.User.IsInRole(AuthCode))
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1403());
                if (!concurrency)
                {
                    lock (lockObject)
                    {
                        var requestId = Encrypt.MD5($"{token}@{api.Request.RequestUri.AbsoluteUri}");
                        if (MemoryCache.Default.Contains(requestId))
                            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1400("请勿重复提交"));
                        else
                            MemoryCache.Default.Set(requestId, 0, DateTime.Now.AddMinutes(1));//1分钟
                    }
                }
            }
        }
    }
    public class WebApiActionFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            //记录日志
            if (actionExecutedContext.Response != null)
            {

                var api = actionExecutedContext.ActionContext.ControllerContext.Controller as ApiController;
                if (api.User.Identity.IsAuthenticated)
                {
                    var identity = api.User.Identity as WebApiAuthIdentity;
                    if (!string.IsNullOrWhiteSpace(identity.Token))
                    {
                        if (identity.SaveCookie)
                        {
                            var cookie = new CookieHeaderValue(ConfigurationManager.AppSettings["AuthHeaderName"], identity.Token)
                            {
                                Expires = DateTime.Now.AddDays(7),
                                Domain = actionExecutedContext.Request.RequestUri.Host,
                                Path = "/"
                            };
                            actionExecutedContext.Response.Headers.AddCookies(new CookieHeaderValue[] { cookie });
                        }
                        var requestId = Encrypt.MD5($"{identity.Token}@{api.Request.RequestUri.AbsoluteUri}");
                        MemoryCache.Default.Set(requestId, 0, DateTime.Now);
                    }
                }
                if (actionExecutedContext.Response.TryGetContentValue(out object ResultContent))
                {
                    var log = new WebApiActionExecutedLogModel()
                    {
                        UserName = api.User.Identity.Name,
                        UserIPAddress = GetUserIPAddress(actionExecutedContext.Request),
                        AbsolutePath = actionExecutedContext.Request.RequestUri.AbsolutePath,
                        Method = actionExecutedContext.Request.Method.Method,
                        ActionArguments = actionExecutedContext.ActionContext.ActionArguments,
                        ResultContent = ResultContent
                    };
                    NLog.LogManager.GetCurrentClassLogger().Info(log);
                    //POST 另作存储处理
                    if (actionExecutedContext.Request.Method == HttpMethod.Post)
                    {
                        WebApiLogConfig.SaveAs(log);
                    }
                }
            }
            base.OnActionExecuted(actionExecutedContext);
        }
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (actionContext.Request.Method == HttpMethod.Options)//跨域
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Accepted);
            else if (!actionContext.ModelState.IsValid)//非法参数
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1406(actionContext.ModelState));
            else if (actionContext.ActionArguments.Any(q => q.Value == null))//缺少参数
            {
                actionContext.ModelState.AddModelError(string.Empty, "请求参数不能为空");
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1406(actionContext.ModelState));
            }
            else if (!SignValid(actionContext) || !ActionValid(actionContext) || !ModelValid(actionContext))//自定义数据库实例验证
            {
                actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1406(actionContext.ModelState));
            }
            var api = actionContext.ControllerContext.Controller as ApiController;
            if (api.User is WebApiAuthPrincipal)
            {
                if (actionContext.Response != null)
                {
                    var identity = api.User.Identity as WebApiAuthIdentity;
                    var requestId = Encrypt.MD5($"{identity.Token}@{api.Request.RequestUri.AbsoluteUri}");
                    MemoryCache.Default.Set(requestId, 0, DateTime.Now);
                }
            }
            else
            {
                //身份验证
                if (actionContext.Request.Headers.TryGetValues(System.Configuration.ConfigurationManager.AppSettings["AuthHeaderName"], out IEnumerable<string> tokens))
                {
                    string token = tokens?.FirstOrDefault() ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(token) || !WebApiAuthConfig.TryGetUserId(token, out string userId))
                        SetWebApiAuthPrincipal(actionContext, string.Empty);
                    else
                        SetWebApiAuthPrincipal(actionContext, userId);
                }
                else
                {
                    var cookie = actionContext.Request.Headers.GetCookies(ConfigurationManager.AppSettings["AuthHeaderName"])
                        .FirstOrDefault()?.Cookies?.FirstOrDefault()?.Value;
                    if (string.IsNullOrWhiteSpace(cookie) || !WebApiAuthConfig.TryGetUserId(cookie, out string userId))
                        SetWebApiAuthPrincipal(actionContext, string.Empty);
                    else
                        SetWebApiAuthPrincipal(actionContext, userId);
                }
            }
            base.OnActionExecuting(actionContext);
        }
        private bool SignValid(HttpActionContext actionContext)
        {
            if (!actionContext.ActionArguments.Any(q => q.Value is TWebApiSignRequest))
                return true;
            var signs = actionContext.ActionArguments.Where(q => q.Value is TWebApiSignRequest).Select(q => q.Value as TWebApiSignRequest).ToArray();
            foreach (var item in signs)
            {
                if (!WebApiSignRequestConfig.ValidSignature(item, actionContext.Request.RequestUri.AbsoluteUri,actionContext.ModelState))
                {
                    return false;
                }
            }
            return true;
        }
        private bool ActionValid(HttpActionContext actionContext)
        {
            if (!actionContext.ActionDescriptor.GetCustomAttributes<DbActionValidAttribute>().Any()) return true;
            var actionValid = actionContext.ActionDescriptor.GetCustomAttributes<DbActionValidAttribute>().First();
            if (!actionContext.ActionArguments.ContainsKey(actionValid.ArgName))
                throw new ArgumentException($"参数【{actionValid.ArgName}】不存在");
            var value = actionContext.ActionArguments[actionValid.ArgName];
            var res = WebApiValidConfig.DbEntityExist(value.ToString(), actionValid.TableName, actionValid.FieldName);
            if (res) return true;
            actionContext.ModelState.AddModelError(actionValid.ArgName, actionValid.ErrorMessage);
            return false;
        }
        private bool ModelValid(HttpActionContext actionContext)
        {
            var args = actionContext.ActionArguments.Where(q => q.Value.GetType().IsClass).ToArray();
            foreach (var item in args)
            {
                var properties = item.Value.GetType().GetProperties();
                foreach (var property in properties)
                {
                    var modelValid = property.GetCustomAttribute<DbModelValidAttribute>();
                    if (modelValid == null) continue;
                    var val = property.GetValue(item.Value);
                    if (val == null) continue;
                    var res = WebApiValidConfig.DbEntityExist(val.ToString(), modelValid.TableName, modelValid.FieldName);
                    if (!res) { actionContext.ModelState.AddModelError(item.Key, modelValid.ErrorMessage); return false; }
                }
            }
            return true;
        }

        private void SetWebApiAuthPrincipal(HttpActionContext actionContext, string userId)
        {
            var api = actionContext.ControllerContext.Controller as ApiController;
            if (api.User is WebApiAuthPrincipal) { }
            else
                api.User = new WebApiAuthPrincipal() { Identity = new WebApiAuthIdentity(userId) };
        }

        private string GetUserIPAddress(HttpRequestMessage httpRequest)
        {
            if (httpRequest.Properties.ContainsKey(MS_HttpContextProperty.Name))
            {
                dynamic ctx = httpRequest.Properties[MS_HttpContextProperty.Name];
                if (ctx != null)
                {
                    return ctx.Request.UserHostAddress;
                }
            }
            if (httpRequest.Properties.ContainsKey(RemoteEndpointMessageProperty.Name))
            {
                dynamic remoteEndpoint = httpRequest.Properties[RemoteEndpointMessageProperty.Name];
                if (remoteEndpoint != null)
                {
                    return remoteEndpoint.Address;
                }
            }
            return "0.0.0.0";
        }
    }
    public class MS_HttpContextProperty
    {
        public static string Name { get; } = "MS_HttpContext";
    }
    public class WebApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            if (actionExecutedContext.Exception is HttpResponseException)
            {
                HttpResponseException httpResponseException = actionExecutedContext.Exception as HttpResponseException;
                NLog.LogManager.GetCurrentClassLogger().Error(actionExecutedContext.Exception);
                NLog.LogManager.GetCurrentClassLogger().Error($"Response:{httpResponseException.Response.StatusCode} {httpResponseException.Response.ReasonPhrase}");
                actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(
                    new WebApiResultBuilder<WebApiResultEmpty>().Error1500($"系统错误【{httpResponseException.Response.StatusCode}:{httpResponseException.Response.ReasonPhrase}】"));
            }
            else if (actionExecutedContext.Exception is DbEntityValidationException)
            {
                DbEntityValidationException dbEntityValidationException = actionExecutedContext.Exception as DbEntityValidationException;
                NLog.LogManager.GetCurrentClassLogger().Error(actionExecutedContext.Exception);
                var entityValidationErrors = dbEntityValidationException.EntityValidationErrors
                    .SelectMany(q => q.ValidationErrors.Select(w => $"{w.PropertyName}:{w.ErrorMessage}"));
                NLog.LogManager.GetCurrentClassLogger().Error($"entityValidationErrors:{string.Join(",", entityValidationErrors)}");
                actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(
                   new WebApiResultBuilder<WebApiResultEmpty>().Error1500($"系统错误【{dbEntityValidationException.Message}】"));
            }
            else
            {
                NLog.LogManager.GetCurrentClassLogger().Error(actionExecutedContext.Exception);
                actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(
                            new WebApiResultBuilder<WebApiResultEmpty>().Error1500($"系统错误【{actionExecutedContext.Exception.Message}】"));
            }

            //base.OnException(actionExecutedContext);
        }
    }
    public class WebApiResult<T> where T : IWebApiResultData
    {
        /// <summary>
        /// 请求结果状态| 1200表示成功， 1400表示已知错误（请直接向用户展示错误描述信息）， 1401表示用户身份验证失败（例如：未登录）， 1403表示权限验证失败（例如：非会员）， 1406表示请求数据验证失败（例如：必填项为空）， 1500表示未知错误（BUG）
        /// </summary>
        public int code { get; set; } = 1200;
        /// <summary>
        /// 请求结果描述
        /// </summary>
        public string msg { get; set; }
        /// <summary>
        /// 请求结果
        /// </summary>
        public T data { get; set; }
    }
    public interface IWebApiResultData { }
    public class WebApiResultEmpty : IWebApiResultData { }
    public class WebApiResultBuilder<dataT> : IDisposable where dataT : IWebApiResultData, new()
    {
        public dataT data { get; set; }

        public WebApiResultBuilder()
        {
            data = new dataT();
        }
        public virtual void Dispose()
        {

        }
    }
    public class WebApiResultBuilder<dataT, dbT> : WebApiResultBuilder<dataT>
        where dataT : IWebApiResultData, new()
        where dbT : DbContext, new()
    {
        public dbT db { get; set; }
        public WebApiResultBuilder() : base()
        {
            db = new dbT();
        }
        public override void Dispose()
        {
            db?.Dispose();
            base.Dispose();
        }
    }
    public static class WebApiResultDataExtansion
    {
        /// <summary>
        /// 1200表示成功
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static WebApiResult<T> Successed<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>() { code = 1200, msg = "成功", data = builder.data };
        }
        /// <summary>
        /// 1500表示未知错误（BUG）
        /// </summary>
        /// <returns></returns>
        public static WebApiResult<T> Error1500<T>(this WebApiResultBuilder<T> builder, string msg) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>() { code = 1500, msg = msg };
        }
        /// <summary>
        /// 1400表示已知错误（请直接向用户展示错误描述信息）
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static WebApiResult<T> Error1400<T>(this WebApiResultBuilder<T> builder, string msg) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>() { code = 1400, msg = msg ?? "未知的错误信息" };
        }
        /// <summary>
        /// 1401表示用户身份验证失败（例如：未登录）
        /// </summary>
        /// <returns></returns>
        public static WebApiResult<T> Error1401<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>() { code = 1401, msg = "需要登录授权" };
        }
        /// <summary>
        /// 1403表示权限验证失败（例如：非会员）
        /// </summary>
        /// <returns></returns>
        public static WebApiResult<T> Error1403<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>() { code = 1403, msg = "没有相关权限" };
        }
        /// <summary>
        /// 1406表示请求数据验证失败（例如：必填项为空）
        /// </summary>
        /// <returns></returns>
        public static WebApiResult<T> Error1406<T>(this WebApiResultBuilder<T> builder, ModelStateDictionary modelState) where T : IWebApiResultData, new()
        {
            return new WebApiResult<T>()
            {
                code = 1406,
                msg = modelState.SelectMany(q => q.Value.Errors.Select(w => w.ErrorMessage)).FirstOrDefault() ?? "数据验证失败"
            };
        }
    }


}

