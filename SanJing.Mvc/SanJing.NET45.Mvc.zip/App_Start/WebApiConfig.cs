﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using $safeprojectname$;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.ServiceModel.Channels;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    public static class WebApiConfig
    {
        /// <summary>
        /// 数字或账号组成
        /// </summary>
        public const string REGULAR_NUM_ABC = "^[A-Za-z0-9]+$";
        /// <summary>
        /// 数字组成
        /// </summary>
        public const string REGULAR_NUM = "^[0-9]*$";
        /// <summary>
        /// 邮箱
        /// </summary>
        public const string REGULAR_EMAIL = @"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
        /// <summary>
        /// 身份证
        /// </summary>
        public const string REGULAR_IDCARD = @"^\d{15}|\d{18}$";
        /// <summary>
        /// 日期
        /// </summary>
        public const string REGULAR_DATE = @"^\d{4}-\d{1,2}-\d{1,2}";

        public static void Register(HttpConfiguration config)
        {
            // Web API 配置和服务

            // Web API 路由
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            //异常处理
            config.Filters.Add(new WebApiExceptionFilterAttribute());
            //过滤器
            config.Filters.Add(new WebApiActionFilterAttribute());

            // 移除XML序列化器
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            // 解决json序列化时的循环引用问题
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
            // json日期格式
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatHandling = DateFormatHandling.MicrosoftDateFormat;
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatString = "yyyy-MM-dd HH:mm:ss";
            //json 空对象处理
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new WebApiJsonContractResolver();
        }
    }
    public class WebApiJsonContractResolver : DefaultContractResolver
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="memberSerialization"></param>
        /// <returns></returns>
        protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
        {
            return type.GetProperties()
                   .Select(p =>
                   {


                       var jp = base.CreateProperty(p, memberSerialization);

                       var CustomAttributes = p.GetCustomAttributes(true);

                       jp.ValueProvider = new JsonDefaultValueProvider(p);//默认值

                       if (CustomAttributes != null && CustomAttributes.Any(q => q is JsonDateTimeFormat))
                       {
                           var dateTimeFormat = CustomAttributes.First(q => q is JsonDateTimeFormat) as JsonDateTimeFormat;
                           jp.Converter = new IsoDateTimeConverter() { DateTimeFormat = dateTimeFormat.Format };//日期格式化
                       }
                       return jp;
                   }).ToList();
        }
    }
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDateTimeFormat : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="format"></param>
        public JsonDateTimeFormat(string format)
        {
            Format = format;
        }
    }
    public class JsonDefaultValueProvider : IValueProvider
    {
        private PropertyInfo _MemberInfo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="memberInfo"></param>
        /// <param name="value"></param>
        public JsonDefaultValueProvider(PropertyInfo memberInfo)
        {
            _MemberInfo = memberInfo;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public object GetValue(object target)
        {
            object result = _MemberInfo.GetValue(target, null);
            if (result == null)
            {
                if (_MemberInfo.PropertyType == typeof(string))
                    return string.Empty;
                if (_MemberInfo.PropertyType.IsArray)
                    return Array.CreateInstance(_MemberInfo.PropertyType.GetElementType(), 0);
                if (_MemberInfo.PropertyType.GetConstructor(Type.EmptyTypes) != null)
                    return Activator.CreateInstance(_MemberInfo.PropertyType);
            }
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>

        public void SetValue(object target, object value)
        {
            _MemberInfo.SetValue(target, value, null);
        }
    }
    public class WebApiAuthorizationFilterAttribute : AuthorizationFilterAttribute
    {
        private string AuthCode { get; set; }
        public WebApiAuthorizationFilterAttribute() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="authCodes">权限代码</param>
        public WebApiAuthorizationFilterAttribute(string authCode)
        {
            AuthCode = authCode;
        }
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            //OPTIONS
            if (actionContext.Request.Method == HttpMethod.Options)
                actionContext.Request.CreateResponse(HttpStatusCode.Accepted);
            else if (!actionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any())
            {
                //身份验证
                if (!actionContext.Request.Headers.TryGetValues(System.Configuration.ConfigurationManager.AppSettings["AuthHeaderName"], out IEnumerable<string> tokens))
                    actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1401());
                else
                {
                    string token = tokens?.FirstOrDefault() ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(token) || !WebApiAuthConfig.TryGetUserId(token, out string userId))
                        actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1401());
                    else
                    {
                        var api = actionContext.ControllerContext.Controller as ApiController;
                        api.User = new WebApiAuthPrincipal() { Identity = new WebApiAuthIdentity(userId) };
                        if (!string.IsNullOrWhiteSpace(AuthCode) && !api.User.IsInRole(AuthCode))
                            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1403());
                    }
                }
            }
        }
    }
}
public class WebApiActionFilterAttribute : ActionFilterAttribute
{
    public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
    {
        //记录日志
        if (actionExecutedContext.Response != null)
        {
            actionExecutedContext.Response.TryGetContentValue(out object ResultContent);
            var api = actionExecutedContext.ActionContext.ControllerContext.Controller as ApiController;
            var log = new WebApiActionExecutedLogModel()
            {
                UserName = api.User.Identity.Name,
                UserIPAddress = GetUserIPAddress(actionExecutedContext.Request),
                AbsolutePath = actionExecutedContext.Request.RequestUri.AbsolutePath,
                Method = actionExecutedContext.Request.Method.Method,
                ActionArguments = actionExecutedContext.ActionContext.ActionArguments,
                ResultContent = ResultContent
            };
            NLog.LogManager.GetCurrentClassLogger().Info(log);
            //POST 另作存储处理
            if (actionExecutedContext.Request.Method == HttpMethod.Post)
            {
                WebApiLogConfig.SaveAs(log);
            }
        }
        base.OnActionExecuted(actionExecutedContext);
    }
    public override void OnActionExecuting(HttpActionContext actionContext)
    {
        if (actionContext.Request.Method == HttpMethod.Options)//跨域
            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Accepted);
        else if (!actionContext.ModelState.IsValid)//非法参数
            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1406(actionContext.ModelState));
        else if (actionContext.ActionArguments.Any(q => q.Value == null))//缺少参数
        {
            actionContext.ModelState.AddModelError(string.Empty, "请求参数不能为空");
            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK, new WebApiResultBuilder<WebApiResultEmpty>().Error1406(actionContext.ModelState));
        }
        else
            base.OnActionExecuting(actionContext);
    }
    private string GetUserIPAddress(HttpRequestMessage httpRequest)
    {
        if (httpRequest.Properties.ContainsKey(MS_HttpContextProperty.Name))
        {
            dynamic ctx = httpRequest.Properties[MS_HttpContextProperty.Name];
            if (ctx != null)
            {
                return ctx.Request.UserHostAddress;
            }
        }
        if (httpRequest.Properties.ContainsKey(RemoteEndpointMessageProperty.Name))
        {
            dynamic remoteEndpoint = httpRequest.Properties[RemoteEndpointMessageProperty.Name];
            if (remoteEndpoint != null)
            {
                return remoteEndpoint.Address;
            }
        }
        return "0.0.0.0";
    }
}
public class MS_HttpContextProperty
{
    public static string Name { get; } = "MS_HttpContext";
}
public class WebApiExceptionFilterAttribute : ExceptionFilterAttribute
{
    public override void OnException(HttpActionExecutedContext actionExecutedContext)
    {

        NLog.LogManager.GetCurrentClassLogger().Error(actionExecutedContext.Exception);
        actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(new WebApiResultBuilder<WebApiResultEmpty>().Error1500());

        //base.OnException(actionExecutedContext);
    }
}
public class WebApiResult<T> where T : IWebApiResultData
{
    /// <summary>
    /// 请求结果状态| 1200表示成功， 1400表示已知错误（请直接向用户展示错误描述信息）， 1401表示用户身份验证失败（例如：未登录）， 1403表示权限验证失败（例如：非会员）， 1406表示请求数据验证失败（例如：必填项为空）， 1500表示未知错误（BUG）
    /// </summary>
    public int code { get; set; } = 1200;
    /// <summary>
    /// 请求结果描述
    /// </summary>
    public string msg { get; set; }
    /// <summary>
    /// 请求结果
    /// </summary>
    public T data { get; set; }
}
public interface IWebApiResultData { }
public class WebApiResultEmpty : IWebApiResultData { }
public class WebapiResultMsg
{
    public readonly static Dictionary<int, string> KeyValues = new Dictionary<int, string>() {
        { 1200, "成功" },
        { 1500, "服务器出问题了，请稍后再试" },
        { 1400, "未知" },
        { 1401, "需要登录" },
        { 1403, "没有权限" },
        { 1406, "请求验证失败" } };
}
public class WebApiResultBuilder<DataT> : IDisposable where DataT : IWebApiResultData, new()
{
    public DataT data { get; private set; }
    public WebApiResultBuilder()
    {
        data = new DataT();
    }
    public virtual void Dispose() { }
}
public class WebApiResultBuilder<DataT, DbT> : WebApiResultBuilder<DataT>
    where DataT : IWebApiResultData, new()
    where DbT : DbContext, new()
{
    public DbT db { get; private set; }
    public WebApiResultBuilder() : base()
    {
        db = new DbT();
    }

    public override void Dispose()
    {
        db?.Dispose();
        base.Dispose();
    }
}
public static class WebApiResultDataExtansion
{
    /// <summary>
    /// 1200表示成功
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <returns></returns>
    public static WebApiResult<T> Successed<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>() { code = 1200, msg = WebapiResultMsg.KeyValues[1200], data = builder.data };
    }
    /// <summary>
    /// 1500表示未知错误（BUG）
    /// </summary>
    /// <returns></returns>
    public static WebApiResult<T> Error1500<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>() { code = 1500, msg = WebapiResultMsg.KeyValues[1500] };
    }
    /// <summary>
    /// 1400表示已知错误（请直接向用户展示错误描述信息）
    /// </summary>
    /// <param name="msg"></param>
    /// <returns></returns>
    public static WebApiResult<T> Error1400<T>(this WebApiResultBuilder<T> builder, string msg) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>() { code = 1400, msg = msg ?? WebapiResultMsg.KeyValues[1400] };
    }
    /// <summary>
    /// 1401表示用户身份验证失败（例如：未登录）
    /// </summary>
    /// <returns></returns>
    public static WebApiResult<T> Error1401<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>() { code = 1401, msg = WebapiResultMsg.KeyValues[1401] };
    }
    /// <summary>
    /// 1403表示权限验证失败（例如：非会员）
    /// </summary>
    /// <returns></returns>
    public static WebApiResult<T> Error1403<T>(this WebApiResultBuilder<T> builder) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>() { code = 1403, msg = WebapiResultMsg.KeyValues[1403] };
    }
    /// <summary>
    /// 1406表示请求数据验证失败（例如：必填项为空）
    /// </summary>
    /// <returns></returns>
    public static WebApiResult<T> Error1406<T>(this WebApiResultBuilder<T> builder, ModelStateDictionary modelState) where T : IWebApiResultData, new()
    {
        return new WebApiResult<T>()
        {
            code = 1406,
            msg = modelState.SelectMany(q => q.Value.Errors.Select(w => w.ErrorMessage)).FirstOrDefault() ?? WebapiResultMsg.KeyValues[1406]
        };
    }
}

