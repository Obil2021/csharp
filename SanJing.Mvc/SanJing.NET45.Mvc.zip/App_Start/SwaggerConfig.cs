using System.Web.Http;
using WebActivatorEx;
using $safeprojectname$;
using Swashbuckle.Application;
using System.Web.Http.Description;
using System.Linq;
using System.IO;
using Swashbuckle.Swagger;
using System.Collections.Generic;
using System.Net.Http;
using System;
using DocsByReflection;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace $safeprojectname$
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                    {
                        c.PrettyPrint();
                        c.MultipleApiVersions(
                            (apiDesc, targetApiVersion) => ResolveVersionSupportByRouteConstraint(apiDesc, targetApiVersion),
                            (vc) =>
                            {
                                vc.Version("app", "ǰ�� �ӿ��ĵ�������ͨ�ýӿڣ�v1.0");
                                vc.Version("cms", "��̨ �ӿ��ĵ�������ͨ�ýӿڣ�v1.0");
                                vc.Version("gen", "ͨ�� �ӿ��ĵ� v1.0");
                            });
                        c.GroupActionsBy(apiDesc => GetControllerName(apiDesc));
                        string xml = GetXmlCommentsPath();
                        if (File.Exists(xml))
                            c.IncludeXmlComments(xml);
                        c.UseFullTypeNameInSchemaIds();
                        c.OperationFilter<SwaggerHttpOperationFilter>();
                    })
                .EnableSwaggerUi(c =>
                    {
                        c.DocumentTitle("API�ĵ�����");
                        c.EnableDiscoveryUrlSelector();
                        c.InjectStylesheet(typeof(SwaggerConfig).Assembly, $"{typeof(SwaggerConfig).Namespace}.Content.swagger.swaggerApi.css");
                        c.InjectJavaScript(typeof(SwaggerConfig).Assembly, $"{typeof(SwaggerConfig).Namespace}.Content.swagger.swaggerApi.js");
                        c.DisableValidator();
                    });
        }
        private static bool ResolveVersionSupportByRouteConstraint(System.Web.Http.Description.ApiDescription apiDesc, string targetApiVersion)
        {
            return apiDesc.ID.Contains("/" + targetApiVersion + "/")
                && apiDesc.ActionDescriptor.ControllerDescriptor.ControllerType.Namespace.EndsWith("." + targetApiVersion)
                && apiDesc.HttpMethod != HttpMethod.Options;//����ʾ��OPTIONS����;
        }
        private static string GetControllerName(ApiDescription apiDesc)
        {
            string descString = "û��˵��";
            var type = apiDesc.ActionDescriptor.ControllerDescriptor.ControllerType;
            var route = apiDesc.ActionDescriptor.ControllerDescriptor.GetCustomAttributes<RoutePrefixAttribute>().FirstOrDefault()?.Prefix;
            if (string.IsNullOrEmpty(route))
            {
                route = apiDesc.RelativePathSansQueryString().Replace(apiDesc.ActionDescriptor.ActionName, string.Empty).TrimEnd('/');
            }
            var ver = apiDesc.GetControllerAndActionAttributes<SwaggerVersionAttribute>()?.OrderByDescending(q => q.Version).FirstOrDefault()?.ToString();
            descString = DocsService.GetXmlFromType(apiDesc.ActionDescriptor.ControllerDescriptor.ControllerType, false)?.InnerText?.Trim() ?? "û��˵��";
            return $"{route}@{descString} {ver}";
        }
        /// <summary>
        /// GetXmlCommentsPath
        /// </summary>
        /// <returns></returns>
        private static string GetXmlCommentsPath()
        {
            return System.Web.HttpRuntime.BinDirectory + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType.Namespace + ".xml";
        }
    }
    /// <summary>
    /// �ӿ�˵��
    /// </summary>
    public class SwaggerVersionAttribute : Attribute
    {
        public double Version { get; set; }
        public string Date { get; set; }
        /// <summary>
        /// �ӿ�˵��
        /// </summary>
        /// <param name="ver">�汾��</param>
        /// <param name="date">����</param>
        /// <param name="remark">ע��˵��</param>
        public SwaggerVersionAttribute(double ver, string date)
        {
            Version = ver;
            Date = date;
        }
        public override string ToString()
        {
            return $"v{Version.ToString()} {Date}";
        }
    }
    /// <summary>
    /// Ĭ�Ϸ���״̬������
    /// </summary>
    public class SwaggerHttpOperationFilter : IOperationFilter
    {
        /// <summary>
        /// Ĭ�Ϸ���״̬������
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            if (operation.responses == null)
                operation.responses = new Dictionary<string, Response>();

            if (operation.parameters == null)
                operation.parameters = new List<Parameter>();

            if (operation.consumes == null)
                operation.consumes = new List<string>();
            if (string.IsNullOrEmpty(operation.summary))
                operation.summary = "û��˵��";
            var version = apiDescription.ActionDescriptor.GetCustomAttributes<SwaggerVersionAttribute>()?.FirstOrDefault()?.ToString();
            if (!string.IsNullOrEmpty(version))
            {
                operation.summary += $" {version}";
            }

            foreach (var item in operation.parameters)
            {
                if (string.IsNullOrEmpty(item.name))
                    continue;
                if (item.name.Trim('.').Contains('.'))
                {
                    item.name = item.name.Substring(item.name.IndexOf('.') + 1);//ȥ��GET�����URL�������е���������
                }
            }

            //1401 ��Ҫ������֤
            if ((!apiDescription.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any())
                && (apiDescription.ActionDescriptor.ControllerDescriptor.GetCustomAttributes<WebApiAuthorizationFilterAttribute>().Any()
                || apiDescription.ActionDescriptor.GetCustomAttributes<WebApiAuthorizationFilterAttribute>().Any()))
            {
                operation.parameters.Add(new Parameter
                {
                    name = System.Configuration.ConfigurationManager.AppSettings["AuthHeaderName"],
                    @in = "header",
                    type = "string",
                    description = "�û�ƾ�ݡ�TOKEN��",
                    required = true
                });
            }
            else if (operation.operationId == SwaggerOperationId.FILE_UPLOAD)
            {
                operation.consumes.Add("multipart/form-data");
                operation.parameters.Add(new Parameter
                {
                    name = "file",
                    @in = "formData",
                    type = "file",
                    description = "multipart/form-data",
                    required = true
                });
            }
        }
    }

    /// <summary>
    /// SwaggerOperationId
    /// </summary>
    public class SwaggerOperationId
    {
        /// <summary>
        /// �ļ��ϴ�
        /// </summary>
        public const string FILE_UPLOAD = "FILE_UPLOAD";
    }
}
