﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.cms
{
    /// <summary>
    /// 账户操作
    /// </summary>
    public class AccountModel
    {
        /// <summary>
        /// 请求模型
        /// </summary>
        public class EditPasswordReq
        {
            /// <summary>
            /// 原密码
            /// HASH加密后的值
            /// </summary>
            [Required]
            [StringLength(128, MinimumLength = 32)]
            [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = "应该为HASH加密（MD5、SHA1等）后的字符格式")]
            public string OldPassword { get; set; }
            /// <summary>
            /// 新密码
            /// HASH加密后的值
            /// </summary>
            [Required]
            [StringLength(128, MinimumLength = 32)]
            [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = "应该为HASH加密（MD5、SHA1等）后的字符格式")]
            public string NewPassword { get; set; }
        }

        /// <summary>
        /// 请求模型
        /// </summary>
        public class LoginReq
        {
            /// <summary>
            /// 账号
            /// 字符+数字
            /// </summary>
            [Required]
            [StringLength(18, MinimumLength = 6)]
            [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = "只能包含字符或数字")]
            public string Account { get; set; }
            /// <summary>
            /// 密码
            /// HASH加密后的值
            /// </summary>
            [Required]
            [StringLength(128, MinimumLength = 32)]
            [RegularExpression(WebApiConfig.REGULAR_NUM_ABC, ErrorMessage = "应该为HASH加密（MD5、SHA1等）后的字符格式")]
            public string Password { get; set; }
        }
        /// <summary>
        /// 返回模型
        /// </summary>
        public class LoginRes : IWebApiResultData
        {
            /// <summary>
            /// 用户凭据
            /// 需要授权的请求需要将此值写入header中
            /// </summary>
            public string Token { get; set; }
        }
    }
}