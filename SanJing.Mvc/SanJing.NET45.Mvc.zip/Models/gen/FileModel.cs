﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.gen
{
    public class FileModel
    {
        public class UploadRes : IWebApiResultData
        {
            /// <summary>
            /// 文件ID，用于提交数据
            /// </summary>
            public string FileId { get; set; }
            /// <summary>
            /// 文件地址，用于预览
            /// </summary>
            public string FileUrl { get; set; }
        }
    }
}