﻿
using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// PageRegisterController
    /// </summary>
    public class PageRegisterPostController : PostApiController<PageRegisterModel.PostResponse, PageRegisterModel.PostRequest>
    {
        /// <summary>
        /// ResultBuilder
        /// </summary>
        /// <param name="res"></param>
        /// <param name="db"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<PageRegisterModel.PostResponse> ResultBuilder(PageRegisterModel.PostResponse res, Entities db, PageRegisterModel.PostRequest request)
        {
            //    // 验证验证码
            //if (!VerifyCodeCacheExtansion.Valid(db, userPostModel.PhoneNum, userPostModel.VerifyCode))
            //   return WebApiResult.Failed1400("验证码无效", res);

            //返回
            var token = WebApiHeaderExtansion.UserIdToToken(request.PhoneNum);
            res.CopyFromTokenModel(token);
            db.SaveChangesWithLog(request.PhoneNum, request);
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 页面|用户注册|注册
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<PageRegisterModel.PostResponse> Post([FromBody] PageRegisterModel.PostRequest request)
        {
            return base.Post(request);
        }

    }
}
