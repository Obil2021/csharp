﻿using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 生成二维码图片
    /// </summary>
    public class ggQrCodeController : GetApiController<ggQrCodeModel.Res, ggQrCodeModel.Req>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        public override WebApiResultModel<ggQrCodeModel.Res> ResultBuilder(ggQrCodeModel.Res res)
        {
            var qrpath = "/content/cache/qrcode_" + SanJing.Hash.Encrypt.MD5(req.Content) + ".png";
            var qrfile = HttpContext.Current.Server.MapPath(qrpath);
            if (!File.Exists(qrfile))
            {
                SanJing.GraphicCode.QRCode.SaveAs(qrfile, req.Content, 5);
            }
            res.QrCodeUrl = FileUrlExtension.ImageFileNameToUrl(qrpath, qrpath);
            return Success(res);
        }
        /// <summary>
        /// 生成二维码图片|全局
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<ggQrCodeModel.Res> Get([FromUri] ggQrCodeModel.Req request)
        {
            return base.Get(request);
        }
    }
}
