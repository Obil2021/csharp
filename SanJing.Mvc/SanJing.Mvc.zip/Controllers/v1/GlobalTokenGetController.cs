﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 
    /// </summary>
    public class GlobalTokenGetController : GetAuthApiController<GlobalTokenModel.GetResponse>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public override WebApiResultModel<GlobalTokenModel.GetResponse> ResultBuilder(GlobalTokenModel.GetResponse res, string userid)
        {
            var token = WebApiHeaderExtansion.UserIdToToken(userid);
            res.CopyFromTokenModel(token);
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 全局|凭据|换取凭据
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<GlobalTokenModel.GetResponse> Get()
        {
            return base.Get();
        }
    }
}
