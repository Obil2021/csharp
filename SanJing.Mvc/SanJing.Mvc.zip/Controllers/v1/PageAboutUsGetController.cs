﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using static $safeprojectname$.Models.v1.PageAboutUsModel;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 关于我们
    /// </summary>
    public class PageAboutUsGetController : GetApiController<GetResponse>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <param name="db"></param>
        /// <returns></returns>

        public override WebApiResultModel<GetResponse> ResultBuilder(GetResponse res, Entities db)
        {
            res.AboutAsURL = this.GetViewURL(new WebApiViewExtansion.ViewData() { FieldName = "AboutUs", Id = 1, TableName = "SystemSetting" });
            return WebApiResult.Succeeded(res);
        }

        /// <summary>
        /// 页面|关于我们|数据
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<GetResponse> Get()
        {
            return base.Get();
        }
    }
}
