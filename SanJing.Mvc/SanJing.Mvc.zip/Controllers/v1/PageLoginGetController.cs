﻿
using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// PageLoginGetController
    /// </summary>
    public class PageLoginGetController : GetApiController<PageLoginModel.GetResponse>
    {
        /// <summary>
        /// ResultBuilder
        /// </summary>
        /// <param name="res"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        public override WebApiResultModel<PageLoginModel.GetResponse> ResultBuilder(PageLoginModel.GetResponse res, Entities db)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 页面|用户登录|数据
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<PageLoginModel.GetResponse> Get()
        {
            return base.Get();
        }
    }
}
