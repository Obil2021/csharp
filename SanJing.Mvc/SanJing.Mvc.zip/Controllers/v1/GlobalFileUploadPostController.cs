﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// GlobalFileUploadController
    /// </summary>
    public class GlobalFileUploadPostController : PostAuthApiController<GlobalFileUploadModel.PostResponse>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public override WebApiResultModel<GlobalFileUploadModel.PostResponse> ResultBuilder(GlobalFileUploadModel.PostResponse res, string userid)
        {
            //保存文件
            var files = HttpContext.Current.Request.Files;
            if (files.Count == 0)
                return WebApiResult.Failed1400("请上传文件", res);

            var file = files[0];
            //文件类型
            var fileex = Path.GetExtension(file.FileName).ToLower();
            var fileexs = new[] { ".jpg", ".jpeg", ".png" };//支持的文件格式
            if (!fileexs.Contains(fileex))
                return WebApiResult.Failed1400("不支持的文件格式", res);

            //md5
            var md5 = new MD5CryptoServiceProvider();
            var retVal = md5.ComputeHash(file.InputStream);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < retVal.Length; i++)
            {
                sb.Append(retVal[i].ToString("x2"));
            }
            var filemd5 = sb.ToString();


            if (db.File.AsNoTracking().Any(q => q.MD5 == filemd5))//已存在
            {
                var filedb = db.File.AsNoTracking().First(q => q.MD5 == filemd5);
                res.FileUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + filedb.PathName;
                res.FilePath = filedb.PathName;
            }
            else//不存在
            {
                var uploads = "/uploads/";
                if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploads))) Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploads));

                var today = $"{uploads}{DateTime.Today.ToString("yyyyMMdd")}/";
                if (!Directory.Exists(HttpContext.Current.Server.MapPath(today))) Directory.CreateDirectory(HttpContext.Current.Server.MapPath(today));

                var filename = $"{today}{Guid.NewGuid().ToString("N")}{fileex}";
                file.SaveAs(HttpContext.Current.Server.MapPath(filename));

                res.FileUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + filename;
                res.FilePath = filename;
                db.File.Add(new DbEF.File()
                {
                    MD5 = filemd5,
                    PathName = filename,
                    Watermark = false,
                });

                db.SaveChanges();
            }
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 全局|文件|上传
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(SwaggerOperationId.FILE_UPLOAD)]
        public override WebApiResultModel<GlobalFileUploadModel.PostResponse> Post()
        {
            return base.Post();
        }
    }
}
