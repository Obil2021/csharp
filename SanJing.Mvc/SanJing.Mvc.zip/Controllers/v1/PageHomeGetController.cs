﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 首页
    /// </summary>
    public class PageHomeGetController : GetAuthApiController<PageHomeModel.GetResponse>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public override WebApiResultModel<PageHomeModel.GetResponse> ResultBuilder(PageHomeModel.GetResponse res, string userid)
        {
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 页面|首页|数据
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<PageHomeModel.GetResponse> Get()
        {
            return base.Get();
        }
    }
}
