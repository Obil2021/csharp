﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// PageMyInfoPostController
    /// </summary>
    public class PageMyInfoPostController : PostAuthApiController<WebApiResultEmptyModel, PageMyInfoModel.PostRequest>
    {
        /// <summary>
        /// 随机种子和锁
        /// </summary>
        public static readonly Random random = new Random();
        /// <summary>
        /// ResultBuilder
        /// </summary>
        /// <param name="res"></param>
        /// <param name="request"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public override WebApiResultModel<WebApiResultEmptyModel> ResultBuilder(WebApiResultEmptyModel res, PageMyInfoModel.PostRequest request, string userid)
        {
            //当修改全局数据时加锁可以避免重复写入
            lock (random)
            {
                db.SaveChangesWithLog(userid, request);
            }

            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 页面|我的信息|修改
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<WebApiResultEmptyModel> Post([FromBody] PageMyInfoModel.PostRequest request)
        {
            return base.Post(request);
        }
    }
}
