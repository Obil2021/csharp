﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// PageLoginPostController
    /// </summary>
    public class PageLoginPostController : PostApiController<PageLoginModel.PostResponse, PageLoginModel.PostRequest>
    {
        /// <summary>
        /// ResultBuilder
        /// </summary>
        /// <param name="res"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<PageLoginModel.PostResponse> ResultBuilder(PageLoginModel.PostResponse res, PageLoginModel.PostRequest request)
        {
            var userid = 1;

            //验证

            //返回
            res.Token = WebApiHeaderExtansion.UserIdToToken(userid);
            db.SaveChangesWithLog(userid, request);
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 页面|用户登录|登录
        /// </summary>
        /// <param name="request">请求实例</param>
        /// <returns>返回实例</returns>
        public override WebApiResultModel<PageLoginModel.PostResponse> Post([FromBody] PageLoginModel.PostRequest request)
        {
            return base.Post(request);
        }
    }
}
