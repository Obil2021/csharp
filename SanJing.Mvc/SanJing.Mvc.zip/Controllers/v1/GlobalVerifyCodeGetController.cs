﻿using $safeprojectname$.DbEF;
using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 验证码
    /// </summary>
    public class GlobalVerifyCodeGetController : GetApiController<WebApiResultEmptyModel, GlobalVerifyCodeModel.PostRequest>
    {
        private static readonly Random random = new Random();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public override WebApiResultModel<WebApiResultEmptyModel> ResultBuilder(WebApiResultEmptyModel res, GlobalVerifyCodeModel.PostRequest request)
        {
            //清理过期验证码
            var vcodes = db.VerifyCodeCache.Where(q => q.Expire < DateTime.Now).ToList();

            foreach (var item in vcodes)
            {
                db.VerifyCodeCache.Remove(item);
            }
            db.SaveChanges();

            //验证
            if (request.UseTypeIsLogin())
            {
                //登录  检查是否存在
            }
            else
            {
                //注册  检查是否不存在
            }

            //生成验证码6位
            var verifyCode = random.Next(100000, 1000000).ToString();
            while (db.VerifyCodeCache.AsNoTracking().Any(q => q.VerifyCode == verifyCode))
            {
                verifyCode = random.Next(100000, 1000000).ToString();
            }

            //发送验证码
            //

            //存储验证码
            db.VerifyCodeCache.Add(new VerifyCodeCache()
            {
                VerifyCode = verifyCode,
                Expire = DateTime.Now.AddMinutes(5),//五分钟
                PhoneNum = request.PhoneNum,
            });

            db.SaveChanges();

            //204
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 全局|验证码|发送验证码
        /// </summary>
        /// <param name="request">请求实例</param>
        /// <returns>返回实例</returns>
        public override WebApiResultModel<WebApiResultEmptyModel> Get([FromUri] GlobalVerifyCodeModel.PostRequest request)
        {
            return base.Get(request);
        }
    }
}
