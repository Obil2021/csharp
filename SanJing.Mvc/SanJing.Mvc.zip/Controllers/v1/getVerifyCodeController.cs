﻿using $safeprojectname$.Models.v1;
using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// 验证码
    /// </summary>
    public class getVerifyCodeController : GetApiController<WebApiEmptyResult, getVerifyCodeModel.Req>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        public override WebApiResultModel<WebApiEmptyResult> ResultBuilder(WebApiEmptyResult res)
        {
            var cache = "/verifycodes";
            if (!Directory.Exists(HttpContext.Current.Server.MapPath(cache))) Directory.CreateDirectory(HttpContext.Current.Server.MapPath(cache));

            var today = $"{cache}/{DateTime.Today.ToString(SanJing.Const.DATE_YYYYMMDD)}";
            if (!Directory.Exists(HttpContext.Current.Server.MapPath(today))) Directory.CreateDirectory(HttpContext.Current.Server.MapPath(today));

            //生成验证码6位
            var verifyCode = SanJing.Const.RANDOM_SEED.Next(100000, 1000000).ToString();

            var cachename = $"{today}/{req.PhoneNum}_{verifyCode}.log";

            while (File.Exists(HttpContext.Current.Server.MapPath(cachename)))
            {
                verifyCode = SanJing.Const.RANDOM_SEED.Next(100000, 1000000).ToString();

                cachename = $"{today}/{req.PhoneNum}_{verifyCode}.log";
            }

            //发送验证码
            //

            //存储验证码
            File.WriteAllText(HttpContext.Current.Server.MapPath(cachename), string.Empty);

            //204
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 发送验证码|全局
        /// </summary>
        /// <param name="request">请求实例</param>
        /// <returns>返回实例</returns>
        public override WebApiResultModel<WebApiEmptyResult> Get([FromUri] getVerifyCodeModel.Req request)
        {
            return base.Get(request);
        }
    }
}
