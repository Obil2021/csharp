﻿using $safeprojectname$.Models.v1;
using Swashbuckle.Swagger.Annotations;
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.v1
{
    /// <summary>
    /// GlobalFileUploadController
    /// </summary>
    public class PostGlobalFileUploadController : PostApiEmptyController<PostGlobalFileUploadModel.Res>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        public override WebApiResultModel<PostGlobalFileUploadModel.Res> ResultBuilder(PostGlobalFileUploadModel.Res res)
        {
            //保存文件
            var files = HttpContext.Current.Request.Files;
            if (files.Count == 0)
                return WebApiResult.Failed1400("请上传文件", res);

            var file = files[0];
            //文件类型
            var fileex = Path.GetExtension(file.FileName).ToLower();
            var fileexs = new[] { ".jpg", ".jpeg", ".png" };//支持的文件格式
            if (!fileexs.Contains(fileex))
                return WebApiResult.Failed1400("不支持的文件格式", res);

            //md5
            var md5 = new MD5CryptoServiceProvider();
            var retVal = md5.ComputeHash(file.InputStream);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < retVal.Length; i++)
            {
                sb.Append(retVal[i].ToString("x2"));
            }

            var filemd5 = sb.ToString();
            var uploads = "/uploads/";
            if (!Directory.Exists(HttpContext.Current.Server.MapPath(uploads)))
                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(uploads));

            var filename = $"{uploads}{filemd5}{fileex}";
            file.SaveAs(HttpContext.Current.Server.MapPath(filename));

            res.FileUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + filename;
            res.FileId = filename;
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 上传文件|全局
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(SwaggerOperationId.FILE_UPLOAD)]
        public override WebApiResultModel<PostGlobalFileUploadModel.Res> Post()
        {
            return base.Post();
        }
    }
}
