﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.cms
{
    public class defaultCmsController : GetApiEmptyController<WebApiEmptyResult>
    {
        public override WebApiResultModel<WebApiEmptyResult> ResultBuilder(WebApiEmptyResult res)
        {
            if (this.TryGetUserId(out int userid))
                return Success(res);
            return WebApiResult.Failed1401(res);
        }
        /// <summary>
        /// 测试接口
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<WebApiEmptyResult> Get()
        {
            return base.Get();
        }
    }
}
