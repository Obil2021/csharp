﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers.app
{
    public class defaultAppController : GetApiEmptyController<WebApiEmptyResult>
    {
        public override WebApiResultModel<WebApiEmptyResult> ResultBuilder(WebApiEmptyResult res)
        {
            WebApiTokenExtansion.UserIdToToken(1);

            return Success(res);
        }
        /// <summary>
        /// 测试接口
        /// </summary>
        /// <returns></returns>
        public override WebApiResultModel<WebApiEmptyResult> Get()
        {
            return base.Get();
        }
    }
}
