﻿using $safeprojectname$.Models.gen;
using Swashbuckle.Swagger.Annotations;
using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.gen
{
    /// <summary>
    /// FileUploadController
    /// </summary>
    public class fileUploadController : PostApiEmptyController<fileUploadModel.Res>
    {
        private const string ID_FILE = "SanJing.Cache.ID_FILE";
        /// <summary>
        /// ResultBuilder
        /// </summary>
        /// <param name="res">Res</param>
        /// <returns></returns>
        public override WebApiResultModel<fileUploadModel.Res> ResultBuilder(fileUploadModel.Res res)
        {
            //保存文件
            var files = HttpContext.Current.Request.Files;
            if (files.Count == 0)
                return WebApiResult.Failed1400("请上传文件", res);

            var file = files[0];
            //文件类型
            var fileex = Path.GetExtension(file.FileName).ToLower();
            var fileexs = new[] { ".jpg", ".jpeg", ".png", ".doc", ".docx", ".xls", ".xlsx", ".pdf" };//支持的文件格式
            if (!fileexs.Contains(fileex))
                return WebApiResult.Failed1400("不支持的文件格式", res);

            var filemd5 = SanJing.Hash.Encrypt.MD5(file.InputStream);
            if (!SanJing.Cache.Mssql.ReadAs(filemd5, ID_FILE, out string filename))
            {
                filename = $"/content/upload/{DateTime.Today:yyyyMMdd}{SanJing.Cache.Mssql.SerialNum(ID_FILE)}{fileex}";
                Directory.CreateDirectory(Path.GetDirectoryName(HttpContext.Current.Server.MapPath(filename)));
                file.SaveAs(HttpContext.Current.Server.MapPath(filename));
                SanJing.Cache.Mssql.SaveAs(filemd5, filename, int.MaxValue, ID_FILE);
            }
            res.FileUrl = FileUrlExtension.FileNameToUrl(filename);
            res.FileId = filename;
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 文件上传|".jpg", ".jpeg", ".png", ".doc", ".docx", ".xls", ".xlsx", ".pdf"
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(SwaggerOperationId.FILE_UPLOAD)]
        public override WebApiResultModel<fileUploadModel.Res> Post()
        {
            return base.Post();
        }
    }
}
