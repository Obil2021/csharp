﻿using $safeprojectname$.Models.gen;
using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.gen
{
    /// <summary>
    /// 验证码
    /// </summary>
    public class verifyCodeSendController : getApiController<WebApiEmptyResult, verifyCodeModel.Req>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        public override WebApiResultModel<WebApiEmptyResult> ResultBuilder(WebApiEmptyResult res)
        {
            //验证验证码
            if (SanJing.Cache.ReadAs(req.PhoneNum, SanJing.Cache.ID_VERCODE + ".Time", out string vcode))
            {
                return Failed1400("你的操作太频繁，请1分钟后再试", res);
            }
            //生成验证码6位
            var verifyCode = SanJing.Const.RANDOM_SEED.Next(100000, 1000000).ToString();


            //发送验证码
            //

            //存储验证码
            SanJing.Cache.SaveAs(req.PhoneNum, verifyCode, 5, SanJing.Cache.ID_VERCODE);
            SanJing.Cache.SaveAs(req.PhoneNum, verifyCode, 1, SanJing.Cache.ID_VERCODE + ".Time");//限制时间1分钟

            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 发送验证码|全局
        /// </summary>
        /// <param name="request">请求实例</param>
        /// <returns>返回实例</returns>
        public override WebApiResultModel<WebApiEmptyResult> Get([FromUri] verifyCodeModel.Req request)
        {
            return base.Get(request);
        }
    }
}
