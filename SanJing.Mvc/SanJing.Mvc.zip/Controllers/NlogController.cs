﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// NlogController
    /// </summary>
    public class NlogController : Controller
    {
        /// <summary>
        /// 日志记录
        /// </summary>
        /// <param name="date">日期【2020-01-01】</param>
        /// <returns></returns>

        public ActionResult Index(string date)
        {
            date = date ?? DateTime.Today.ToString("yyyy-MM-dd");
            return Redirect("/content/logs/" + date + ".html");
        }

    }
}
