﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// APP网页显示
    /// </summary>
    public class AppController : BaseMvcController
    {
        /// <summary>
        /// 隐私策略
        /// </summary>
        /// <returns></returns>
        public ActionResult PrivacyPolicy()
        {
            return View();
        }
        /// <summary>
        /// 用户协议
        /// </summary>
        /// <returns></returns>
        public ActionResult UserAgreement()
        {
            return View();
        }
        /// <summary>
        /// APP关于我们
        /// </summary>
        /// <returns></returns>
        public ActionResult Index(string viewData)
        {
            if (string.IsNullOrWhiteSpace(viewData))
                return HttpNotFound();
            try
            {
                var vdata = WebApiViewExtansion.GetViewData(viewData);
                ViewBag.HTML = db.Database.SqlQuery<string>($"select [{vdata.TableName}].[{vdata.FieldName}] from [{vdata.TableName}] where id = '{vdata.Id}'")
                    .SingleOrDefault();
                return View();
            }
            catch
            {
                return HttpNotFound();
            }
        }

    }
}
