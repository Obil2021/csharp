﻿using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 有请求参数有Token验证GET方法接口基类
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Req">请求类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class GetApiAuthController<Res, Req, Db> : GetApiController<Res, Req, Db>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
        where Req : class, new()
    {
        /// <summary>
        /// Get
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet]
        [SwaggerOperation(SwaggerOperationId.TOKEN_AUTH)]
        public override WebApiResultModel<Res> Get([FromUri] Req request)
        {
            return base.Get(request);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        [NonAction]
        public override WebApiResultModel<Res> ResultBuilder(Res res)
        {
            if (!this.TryGetUserId(out int userid)) return WebApiResult.Failed1401(res);//身份验证

            return ResultBuilder(res, userid);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res, int userid);
    }

    /// <summary>
    /// 无请求参数有Token验证GET方法接口基类
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class GetApiAuthEmptyController<Res, Db> : GetApiEmptyController<Res, Db>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
    {
        /// <summary>
        /// Get
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [SwaggerOperation(SwaggerOperationId.TOKEN_AUTH)]
        public override WebApiResultModel<Res> Get()
        {
            return base.Get();
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        [NonAction]
        public override WebApiResultModel<Res> ResultBuilder(Res res)
        {
            if (!this.TryGetUserId(out int userid)) return WebApiResult.Failed1401(res);//身份验证

            return ResultBuilder(res, userid);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res, int userid);
    }
}
