﻿using Newtonsoft.Json;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{

    /// <summary>
    /// 有请求参数有Token验证Post方法接口基类
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Req">请求类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class PostApiAuthController<Res, Req, Db> : PostApiController<Res, Req, Db>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
        where Req : class, new()
    {
        /// <summary>
        /// Post
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SwaggerOperation(SwaggerOperationId.TOKEN_AUTH)]
        public override WebApiResultModel<Res> Post([FromBody]Req request)
        {
            return base.Post(request);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <returns></returns>
        [NonAction]
        public override WebApiResultModel<Res> ResultBuilder(Res res)
        {
            if (!this.TryGetUserId(out int userid)) return WebApiResult.Failed1401(res);//身份验证

            var result = ResultBuilder(res, userid);

            if (result.code == 1200)
            {
                //记录日志：接口地址，请求数据，用户ID,客户IP，操作时间
                //var apiurl = Request.RequestUri.AbsolutePath;
                //var apireq = JsonConvert.SerializeObject(req);
                //var apiuid = userid.ToString();
                //var cliipa = HttpContext.Current.Request.UserHostAddress;
                //var logtim = DateTime.Now.ToString(SanJing.Const.DATE_YYYYMMDDHHMMSS);
            }
            return result;
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="userid">用户标识</param>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res, int userid);
    }
}

