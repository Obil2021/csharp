﻿using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 无请求参数有Token验证Post方法接口基类
    /// </summary>
    /// <typeparam name="ResultT"></typeparam>
    public abstract class PostAuthApiController<ResultT> : ApiController where ResultT : class, new()
    {
        /// <summary>
        /// Post
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SwaggerOperation(SwaggerOperationId.TOKEN_AUTH)]
        public virtual WebApiResultModel<ResultT> Post()
        {
            var res = new ResultT();

            if (!this.TryGetUserId(out string userid)) WebApiResult.Failed1401(res);

            using (var db = new DbEF.Entities())
            {

                return ResultBuilder(res, db, userid);
            }
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="db">数据库实例</param>
        /// <param name="userid">用户标识</param>
        [NonAction]
        public abstract WebApiResultModel<ResultT> ResultBuilder(ResultT res, DbEF.Entities db, string userid);
    }

    /// <summary>
    /// 有请求参数有Token验证Post方法接口基类
    /// </summary>
    /// <typeparam name="ResultT"></typeparam>
    /// <typeparam name="RequestT"></typeparam>
    public abstract class PostAuthApiController<ResultT, RequestT> : ApiController where ResultT : class, new() where RequestT : class, new()
    {
        /// <summary>
        /// Post
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        public virtual WebApiResultModel<ResultT> Post([FromBody]RequestT request)
        {
            var res = new ResultT();

            if (!ModelState.IsValid) return WebApiResult.Failed1406(ModelState, res);//请求验证

            if (!this.TryGetUserId(out string userid)) WebApiResult.Failed1401(res);//身份验证

            using (var db = new DbEF.Entities())
            {
                return ResultBuilder(res, db, request, userid);
            }
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="db">数据库实例</param>
        /// <param name="request"></param>
        /// <param name="userid">用户标识</param>
        [NonAction]
        public abstract WebApiResultModel<ResultT> ResultBuilder(ResultT res, DbEF.Entities db, RequestT request, string userid);
    }
}

