﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    public abstract class PostApiAuthedController<Res, Req, Db, User> : PostApiAuthController<Res, Req, Db>
         where Db : System.Data.Entity.DbContext, new()
         where Res : class, new()
         where Req : class, new()
         where User : IAuthedUser, new()
    {
        public override WebApiResultModel<Res> ResultBuilder(Res res, int userid)
        {
            User user = new User();
            if (!user.Authed(userid, AuthCode())) return WebApiResult.Failed1403(res);
            return ResultBuilder(res, user);
        }

        public abstract WebApiResultModel<Res> ResultBuilder(Res res, User user);

        public virtual int AuthCode() { return 0; }
    }
}
