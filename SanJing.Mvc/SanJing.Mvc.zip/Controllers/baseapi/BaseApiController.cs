﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// WebApi基类
    /// </summary>
    public class BaseApiController<Res> : ApiController
         where Res : class, new()
    {
        /// <summary>
        /// 跨域
        /// </summary>
        /// <returns></returns>
        [HttpOptions]
        public HttpResponseMessage Options()
        {
            return Request.CreateResponse(HttpStatusCode.Accepted);
        }
        /// <summary>
        /// 1200表示成功
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        [NonAction]
        public WebApiResultModel<Res> Success(Res res)
        {
            return WebApiResult.Succeeded(res);
        }
        /// <summary>
        /// 1400表示已知错误（请直接向用户展示错误描述信息）
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="res"></param>
        /// <returns></returns>
        [NonAction]
        public WebApiResultModel<Res> Failed1400(string msg, Res res)
        {
            return WebApiResult.Failed1400(msg, res);
        }
        /// <summary>
        /// 1403表示权限验证失败（例如：无权限）
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        [NonAction]
        public WebApiResultModel<Res> Failed1403(Res res)
        {
            return WebApiResult.Failed1403(res);
        }
    }
}
