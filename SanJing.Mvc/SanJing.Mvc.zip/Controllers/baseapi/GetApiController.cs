﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 无请求参数GET方法接口基类 
    /// </summary>
    public abstract class GetApiController<ResultT> : ApiController where ResultT : class, new()
    {
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual WebApiResultModel<ResultT> Get()
        {
            var res = new ResultT();

            using (var db = new DbEF.Entities())
            {
                return ResultBuilder(res, db);
            }
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="db">数据库实例</param>
        [NonAction]
        public abstract WebApiResultModel<ResultT> ResultBuilder(ResultT res, DbEF.Entities db);
    }

    /// <summary>
    /// 有请求参数GET方法接口基类 
    /// </summary>
    public abstract class GetApiController<ResultT, RequestT> : ApiController where ResultT : class, new() where RequestT : class, new()
    {
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual WebApiResultModel<ResultT> Get([FromUri]RequestT request)
        {
            var res = new ResultT();

            if (!ModelState.IsValid) return WebApiResult.Failed1406(ModelState, res);//请求验证

            using (var db = new DbEF.Entities())
            {
                return ResultBuilder(res, db, request);
            }
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="db">数据库实例</param>
        /// <param name="request"></param>
        [NonAction]
        public abstract WebApiResultModel<ResultT> ResultBuilder(ResultT res, DbEF.Entities db, RequestT request);
    }
}
