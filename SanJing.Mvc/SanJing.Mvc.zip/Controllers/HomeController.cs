﻿using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 首页
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>

        public ActionResult Index()
        {
            return RedirectToAction("Api");
        }

        public ActionResult Api()
        {
            return View();
        }
    }
}
