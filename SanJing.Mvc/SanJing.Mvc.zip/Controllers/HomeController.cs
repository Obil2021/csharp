﻿

using $safeprojectname$.Models.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 首页
    /// </summary>
    [Authorize]
    public class HomeController : BaseMvcController
    {
        /// <summary>
        /// 关于我们
        /// </summary>
        /// <returns></returns>
        public ActionResult AboutUs()
        {
            var res = new AboutUsModel();
            //    res.Content = db.SystemSetting.AsNoTracking().Single().AboutUs;
            return View(res);
        }

        /// <summary>
        /// 关于我们
        /// </summary>
        /// <param name="aboutUsModel"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult AboutUs(AboutUsModel aboutUsModel)
        {
            if (ModelState.IsValid)
            {
                var images = aboutUsModel.Content.Split(',');
                foreach (var item in images)
                {
                    if (!FileUrlExtension.UrlToFileName(item, out string filename))
                    {
                        return View(aboutUsModel);
                    }
                }
                //    db.SystemSetting.Single().AboutUs = aboutUsModel.Content;
                //    db.SaveChanges();
            }
            return View(aboutUsModel);
        }

        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>

        public ActionResult Index()
        {
            var susers = db.SystemUser.AsNoTracking().ToArray();

            return View(new IndexModel() { UserName = User.Identity.Name });
        }

        /// <summary>
        /// 起始页
        /// </summary>
        /// <returns></returns>

        public ActionResult Start()
        {
            var start = new StartModel
            {
                IncomeAll = "0.00",
                IncomeYear = "0.00",
                IncomeMonth = "0.00",
                IncomeDay = "0.00",
                OrderAll = "0",
                OrderYear = "0",
                OrderMonth = "0",
                OrderDay = "0",
                UserAll = "0",
                UserYear = "0",
                UserMonth = "0",
                UserDay = "0",
            };

            return View(start);
        }
    }
}
