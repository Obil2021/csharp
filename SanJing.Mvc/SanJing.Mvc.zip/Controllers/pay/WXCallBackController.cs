﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers.pay
{
    /// <summary>
    /// 微信支付回调
    /// </summary>
    public class WXCallBackController : ApiController
    {
        private static readonly Random Random = new Random();
        /// <summary>
        /// 回调
        /// </summary>
        /// <returns></returns>
        public string Post()
        {
            return SanJing.ThridPay.Wxpay.PayCallBack(HttpContext.Current.Request.InputStream, PayExtansion.WX_MCHKEY, (ordernum, amount) =>
            {
                //逻辑处理

            }, e =>
            {
                NLogExtension.Error(e.ToString());
            });

        }
    }
}
