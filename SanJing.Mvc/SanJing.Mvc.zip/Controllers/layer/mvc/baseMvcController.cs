﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 基础控制器
    /// </summary>
    public abstract class baseMvcController<Db> : Controller
        where Db : System.Data.Entity.DbContext, new()
    {
        /// <summary>
        /// 数据库实例
        /// </summary>
        public Db db { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        public baseMvcController()
        {
            db = new Db();
        }
        /// <summary>
        /// 释放资源
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

    }
}
