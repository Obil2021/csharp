﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 有请求参数GET方法接口基类(不含数据库实例)
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Req">请求类型</typeparam>
    public abstract class getApiController<Res, Req> : baseApiController<Res>
        where Res : class, new()
        where Req : class, new()
    {
        /// <summary>
        /// 请求参数
        /// </summary>
        public Req req { get; set; }
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual WebApiResultModel<Res> Get([FromUri]Req request)
        {
            var res = new Res();

            req = request;
            if (!ModelState.IsValid) return WebApiResult.Failed1406(ModelState, res);//请求验证

            if (req is IModelStateAppendValid)
            {
                IModelStateAppendValid ireq = res as IModelStateAppendValid;
                if (ireq != null)
                {
                    ireq.Valid(ModelState);

                    if (!ModelState.IsValid) return WebApiResult.Failed1406(ModelState, res);//请求验证
                }
            }
            try
            {
                return ResultBuilder(res);
            }
            catch (DbEntityValidationException ex)
            {
                var newex = new Exception(string.Join(";",
                        ex.EntityValidationErrors.SelectMany(q => q.ValidationErrors.Select(w => $"{w.PropertyName}:{w.ErrorMessage}"))), ex);
                NLogExtension.Error(newex.ToString(), Newtonsoft.Json.JsonConvert.SerializeObject(new { Request.RequestUri.AbsoluteUri, res, req }));
            }
            catch (Exception ex)
            {
                NLogExtension.Error(ex.ToString(), Newtonsoft.Json.JsonConvert.SerializeObject(new { Request.RequestUri.AbsoluteUri, res, req }));
            }
            return WebApiResult.Failed1500(res);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res);

    }
    /// <summary>
    /// 有请求参数GET方法接口基类(含数据库实例)
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Req">请求类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class getApiController<Res, Req, Db> : getApiController<Res, Req>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
        where Req : class, new()
    {
        /// <summary>
        /// 数据库实例
        /// </summary>
        public Db db { get; set; }
        /// <summary>
        /// 实例化
        /// </summary>
        public getApiController()
        {
            db = new Db();
        }
        /// <summary>
        /// 释放数据库
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
    /// <summary>
    /// 有请求参数GET方法接口基类(不含数据库实例)
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    public abstract class GetApiEmptyController<Res> : baseApiController<Res>
        where Res : class, new()
    {
        /// <summary>
        /// GET
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public virtual WebApiResultModel<Res> Get()
        {
            var res = new Res();

            try
            {
                return ResultBuilder(res);
            }
            catch (DbEntityValidationException ex)
            {
                var newex = new Exception(string.Join(";",
                        ex.EntityValidationErrors.SelectMany(q => q.ValidationErrors.Select(w => $"{w.PropertyName}:{w.ErrorMessage}"))), ex);
                NLogExtension.Error(newex.ToString(), Newtonsoft.Json.JsonConvert.SerializeObject(new { Request.RequestUri.AbsoluteUri, res }));
            }
            catch (Exception ex)
            {
                NLogExtension.Error(ex.ToString(), Newtonsoft.Json.JsonConvert.SerializeObject(new { Request.RequestUri.AbsoluteUri, res }));
            }
            return WebApiResult.Failed1500(res);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res);
    }

    /// <summary>
    /// 有请求参数GET方法接口基类(含数据库实例)
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class GetApiEmptyController<Res, Db> : GetApiEmptyController<Res>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
    {
        /// <summary>
        /// 数据库实例
        /// </summary>
        public Db db { get; set; }
        /// <summary>
        /// 实例化
        /// </summary>
        public GetApiEmptyController()
        {
            db = new Db();
        }
        /// <summary>
        /// 释放数据库
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }

}
