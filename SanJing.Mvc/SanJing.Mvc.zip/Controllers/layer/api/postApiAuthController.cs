﻿using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$.Controllers
{

    /// <summary>
    /// 有请求参数有Token验证Post方法接口基类
    /// </summary>
    /// <typeparam name="Res">返回类型</typeparam>
    /// <typeparam name="Req">请求类型</typeparam>
    /// <typeparam name="Db">数据库类型</typeparam>
    public abstract class postApiAuthController<Res, Req, Db> : postApiController<Res, Req, Db>
        where Db : System.Data.Entity.DbContext, new()
        where Res : class, new()
        where Req : class, new()
    {
        /// <summary>
        /// Post
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SwaggerOperation(SwaggerOperationId.TOKEN_AUTH)]
        public override WebApiResultModel<Res> Post([FromBody]Req request)
        {
            return base.Post(request);
        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <returns></returns>
        [NonAction]
        public override WebApiResultModel<Res> ResultBuilder(Res res)
        {
            if (!this.TryGetUserId(out int userid)) return WebApiResult.Failed1401(res);//身份验证

            var result = ResultBuilder(res, userid);
            if (result.code == 1200)//成功
            {

                OperationLogDescription(out int role, out string desc, out bool islog);
                if (islog)
                {
                    try
                    {
                        //记录日志
                        SanJing.Log.SaveAs(new LogItem()
                        {
                            UserId = userid,
                            IPAddress = HttpContext.Current.Request.UserHostAddress ?? "0.0.0.0",
                            Description = desc,
                            Role = role,
                            Content = Newtonsoft.Json.JsonConvert.SerializeObject(req),
                            AbsolutePath = Request.RequestUri.AbsolutePath
                        });
                    }
                    catch (Exception ex)
                    {
                        NLogExtension.Error(ex.ToString());
                    }
                }
            }
            return result;

        }
        /// <summary>
        /// 结果生成器
        /// </summary>
        /// <param name="res">结果实例</param>
        /// <param name="userid">用户标识</param>
        [NonAction]
        public abstract WebApiResultModel<Res> ResultBuilder(Res res, int userid);

        /// <summary>
        /// 操作日志描述
        /// </summary>
        /// <param name="role">角色类型</param>
        /// <param name="desc">操作描述</param>
        /// <param name="islog">是否记录日志|默认:false</param>
        [NonAction]
        public virtual void OperationLogDescription(out int role, out string desc, out bool islog)
        {
            role = 0;
            desc = GetType().Name;
            islog = false;
            var type = GetType();
            var methodInfo = type.GetMethods().FirstOrDefault(q => q.Name.ToLower() == Request.Method.Method.ToLower());
            if (methodInfo != null)
            {
                var methodDoc = DocsByReflection.DocsService.GetXmlFromMember(methodInfo, false);
                desc = methodDoc?.InnerText?.Trim() ?? desc;
            }
        }
    }
}

