﻿

using $safeprojectname$.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 系统用户登录
    /// </summary>
    public class UserController : BaseMvcController
    {
        /// <summary>
        /// 忘记密码
        /// </summary>
        /// <returns></returns>
        public ActionResult ForgetPassword()
        {
            return View();
        }
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <returns></returns>
        [Authorize]
        public ActionResult EditPassword()
        {
            return View();
        }
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="editPasswordModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public ActionResult EditPassword(EditPasswordModel editPasswordModel)
        {
            if (ModelState.IsValid)
            {
                //加密
                string sha1Password = SanJing.Hash.Encrypt.SHA1(editPasswordModel.OldPassword);

                //查询
                if (!db.SystemUser.AsNoTracking().Any(q => q.Account == User.Identity.Name && q.Password == sha1Password))
                {
                    ModelState.AddModelError("", "旧密码不正确");
                    return View(editPasswordModel);
                }

                //修改
                sha1Password = SanJing.Hash.Encrypt.SHA1(editPasswordModel.NewPassword);
                db.SystemUser.Single(q => q.Account == User.Identity.Name).Password = sha1Password;

                db.SaveChangesWithLog(User.Identity.Name, editPasswordModel, editPasswordModel.OldPassword, editPasswordModel.NewPassword);

                return RedirectToAction("Login");
            }
            return View(editPasswordModel);
        }
        /// <summary>
        /// 登录
        /// </summary>
        /// <returns></returns>

        public ActionResult Login()
        {
            FormsAuthentication.SignOut();
            return View();
        }
        /// <summary>
        /// 登录
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel loginModel, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                //加密
                string sha1Password = SanJing.Hash.Encrypt.SHA1(loginModel.Password);

                //查询
                if (!db.SystemUser.AsNoTracking().Where(q => q.Statu >= 0).Any(q => q.Account == loginModel.Account && q.Password == sha1Password))
                {
                    ModelState.AddModelError("", "账户或密码不正确");
                    return View(loginModel);
                }
                var user = db.SystemUser.AsNoTracking().Single(q => q.Account == loginModel.Account && q.Password == sha1Password);
                if (user.Statu != 0)
                {
                    ModelState.AddModelError("", "账户不可用");
                    return View(loginModel);
                }

                //日志
                db.SaveChangesWithLog(loginModel.Account, loginModel, loginModel.Password);

                //存储凭据
                FormsAuthentication.SetAuthCookie(loginModel.Account, false);

                //if (Url.IsLocalUrl(returnUrl))
                //{

                //}
                return RedirectToAction("Index", "Home");
            }
            return View(loginModel);
        }
    }
}
