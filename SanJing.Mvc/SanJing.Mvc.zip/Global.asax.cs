﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;

namespace $safeprojectname$
{
    // 注意: 有关启用 IIS6 或 IIS7 经典模式的说明，
    // 请访问 http://go.microsoft.com/?LinkId=9394801

    /// <summary>
    /// MvcApplication
    /// </summary>
    public class MvcApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// Application_Start
        /// </summary>
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            //Token缓存
            WebApiTokenExtansion.CacheLoad();
        }
        protected void Application_Error(object sender, EventArgs e)
        {
            Exception lastError = Server.GetLastError();
            if (lastError != null)
            {
                //数据库验证异常
                if (lastError is DbEntityValidationException)
                {
                    var ex = lastError as DbEntityValidationException;
                    if (ex.EntityValidationErrors.Count() > 0)
                        lastError = new System.Exception(string.Join(";",
                            ex.EntityValidationErrors.SelectMany(q => q.ValidationErrors.Select(w => $"{w.PropertyName}:{w.ErrorMessage}"))), ex);
                }

                //记录
                var requestParams = Request.Params;
                string jsonParams = JsonConvert.SerializeObject(requestParams.AllKeys.ToDictionary(k => k, k => requestParams[k]), Formatting.Indented);//请求实列

                Request.InputStream.Position = 0;
                var requestContent = new StreamReader(Request.InputStream, Encoding.UTF8).ReadToEnd();//请求内容
                NLogExtension.Error(lastError.ToString(), requestContent, jsonParams);

                //导航到错误页
                if (Request.Url.AbsolutePath.ToLower().StartsWith("/api/"))
                {
                    Response.StatusCode = 200;
                    Response.ContentType = "application/json";
                    Response.Write(JsonConvert.SerializeObject(WebApiResult.Failed1500(new WebApiEmptyResult())));
                }
                else
                {
                    Response.StatusCode = 500;
                }

                Server.ClearError();
            }
        }
    }
}