﻿$(document).ready(function () {
    $('.resource > .heading .options').each(function (i, r) {
        $(r).children().each(function (j, ul) {
            if (j == 1) {
                $(ul).hide();
            }
        });
    });
});