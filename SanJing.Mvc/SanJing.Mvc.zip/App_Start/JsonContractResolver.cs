﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// 
    /// </summary>
    public class JsonContractResolver : DefaultContractResolver
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="memberSerialization"></param>
        /// <returns></returns>
        protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
        {
            return type.GetProperties()
                   .Select(p =>
                   {


                       var jp = base.CreateProperty(p, memberSerialization);

                       var CustomAttributes = p.GetCustomAttributes(true);

                       jp.ValueProvider = new DefaultValueProvider(p);//默认值

                       if (CustomAttributes != null && CustomAttributes.Any(q => q is JsonDateTimeFormat))
                       {
                           var dateTimeFormat = CustomAttributes.First(q => q is JsonDateTimeFormat) as JsonDateTimeFormat;
                           jp.Converter = new IsoDateTimeConverter() { DateTimeFormat = dateTimeFormat.Format };//日期格式化
                       }
                       return jp;
                   }).ToList();
        }
    }
    /// <summary>
    /// 默认值
    /// </summary>
    public class DefaultValueProvider : IValueProvider
    {
        private PropertyInfo _MemberInfo { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="memberInfo"></param>
        /// <param name="value"></param>
        public DefaultValueProvider(PropertyInfo memberInfo)
        {
            _MemberInfo = memberInfo;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public object GetValue(object target)
        {
            object result = _MemberInfo.GetValue(target, null);

            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>

        public void SetValue(object target, object value)
        {
            _MemberInfo.SetValue(target, value, null);
        }
    }
}