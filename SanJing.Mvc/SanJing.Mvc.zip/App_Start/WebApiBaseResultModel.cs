﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    /// <summary>
    /// 
    /// </summary>
    public class WebApiResult
    {
        /// <summary>
        /// 请求结果状态|
        /// 1200表示成功，
        /// 1400表示已知错误（请直接向用户展示错误描述信息），
        /// 1401表示用户身份验证失败（例如：未登录），
        /// 1403表示权限验证失败（例如：非会员），
        /// 1406表示请求数据验证失败（例如：必填项为空），
        /// 1500表示未知错误（BUG）
        /// </summary>
        public int code { get; set; }
        /// <summary>
        /// 请求结果描述
        /// </summary>
        public string msg { get; set; }

        /// <summary>
        /// 1200表示成功
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Succeeded<ResultT>(ResultT result) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1200,
                msg = "成功",
                data = result
            };
        }
        /// <summary>
        /// 1400表示已知错误（请直接向用户展示错误描述信息）
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="msg"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Failed1400<ResultT>(string msg, ResultT result = null) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1400,
                msg = msg,
                data = result
            };
        }
        /// <summary>
        /// 1401表示用户身份验证失败（例如：未登录）
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Failed1401<ResultT>(ResultT result = null) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1401,
                msg = "未登录",
                data = result
            };
        }
        /// <summary>
        /// 1403表示权限验证失败（例如：非会员）
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Failed1403<ResultT>(ResultT result = null) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1403,
                msg = "非会员",
                data = result
            };
        }
        /// <summary>
        /// 1406表示请求数据验证失败（例如：必填项为空）
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="modelState"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Failed1406<ResultT>(ModelStateDictionary modelState, ResultT result = null) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1406,
                msg = string.Join(Environment.NewLine, modelState.Values.SelectMany(q => q.Errors.Select(w => w.ErrorMessage))),
                data = result
            };
        }

        /// <summary>
        /// 1500表示未知错误（BUG）
        /// </summary>
        /// <typeparam name="ResultT"></typeparam>
        /// <param name="result"></param>
        /// <returns></returns>
        public static WebApiResultModel<ResultT> Failed1500<ResultT>(ResultT result = null) where ResultT : class, new()
        {
            return new WebApiResultModel<ResultT>()
            {
                code = 1500,
                msg = "系统维护，请稍后再试！",
                data = result
            };
        }
    }
    /// <summary>
    /// 空返回模型
    /// </summary>
    public class WebApiResultEmptyModel
    {

    }
    /// <summary>
    /// WEBAPI基础返回模型
    /// </summary>
    public class WebApiResultModel<ResultT> : WebApiResult where ResultT : class, new()
    {

        /// <summary>
        /// 请求返回结果
        /// </summary>
        public ResultT data { get; set; }
    }
}