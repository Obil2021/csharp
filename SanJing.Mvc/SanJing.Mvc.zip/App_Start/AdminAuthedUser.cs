﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.App_Start
{
    /// <summary>
    /// 系统账户授权
    /// </summary>
    public class AdminAuthedUser : IAuthedUser
    {
        /// <summary>
        /// 用户读取并作权限判断
        /// </summary>
        /// <param name="userid"></param>
        /// <param name="authCode"></param>
        /// <returns></returns>
        public bool Authed(int userid, int authCode)
        {
            //user = db.user

            //user.hasAuth(authCode);

            throw new NotImplementedException();
        }
    }
}