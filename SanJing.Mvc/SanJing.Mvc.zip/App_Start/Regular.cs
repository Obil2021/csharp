﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    public class Regular
    {
        /// <summary>
        /// 数字或账号组成
        /// </summary>
        public const string NUM_ABC = "^[A-Za-z0-9]+$";
        /// <summary>
        /// 数字组成
        /// </summary>
        public const string NUM = "^[0-9]*$";
        /// <summary>
        /// 邮箱
        /// </summary>
        public const string EMAIL = @"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
        /// <summary>
        /// 身份证
        /// </summary>
        public const string IDCARD = @"^\d{15}|\d{18}$";
        /// <summary>
        /// 日期
        /// </summary>
        public const string DATE = @"^\d{4}-\d{1,2}-\d{1,2}";

    }
}