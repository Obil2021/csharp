﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// webapi返回的页面扩展
    /// </summary>
    public static class WebApiViewExtansion
    {
        /// <summary>
        /// 获取地址
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public static string GetViewURL(this ApiController apiController, string action)
        {
            return apiController.Request.RequestUri.GetLeftPart(UriPartial.Authority) + $"/app/{action}";
        }
        /// <summary>
        /// 获取地址
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="viewData"></param>
        /// <returns></returns>
        public static string GetViewURL(this ApiController apiController, ViewData viewData)
        {
            var vdata = GetViewDataString(viewData);

            return apiController.Request.RequestUri.GetLeftPart(UriPartial.Authority) + $"/app/index?viewdata={vdata}";
        }
        /// <summary>
        /// 获取参数加密数据
        /// </summary>
        /// <param name="viewData"></param>
        /// <returns></returns>

        public static string GetViewDataString(ViewData viewData)
        {
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(viewData);
            var hash = SanJing.Hash.Encrypt.AES128(json);
            return HttpUtility.UrlEncode(hash);
        }
        /// <summary>
        /// 获取参数解密数据
        /// </summary>
        /// <param name="viewDataString"></param>
        /// <returns></returns>
        public static ViewData GetViewData(string viewDataString)
        {
            var hash = SanJing.Hash.Decrypt.AES128(viewDataString);
            var json = Newtonsoft.Json.JsonConvert.DeserializeObject<ViewData>(hash);
            return json;
        }

        /// <summary>
        /// 传输数据
        /// </summary>
        public class ViewData
        {
            /// <summary>
            /// 表名
            /// </summary>
            public string TableName { get; set; }
            /// <summary>
            /// ID
            /// </summary>
            public int Id { get; set; }
            /// <summary>
            /// 字段名
            /// </summary>
            public string FieldName { get; set; }
        }
    }
}