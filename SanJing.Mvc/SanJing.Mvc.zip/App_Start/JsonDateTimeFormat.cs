﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// Json序列化时间格式
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDateTimeFormat : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="format"></param>
        public JsonDateTimeFormat(string format = SanJing.Const.DATE_YYYYMMDDHHMMSS)
        {
            Format = format;
        }
    }
}