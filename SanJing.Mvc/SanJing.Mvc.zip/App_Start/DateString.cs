﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.App_Start
{
    /// <summary>
    /// 日期字符串
    /// </summary>
    public class DateString
    {
        private string _value;
        /// <summary>
        /// 
        /// </summary>
        public DateString() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        public DateString(string value) { _value = value; }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateString(string value)
        {
            return new DateString(value);
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateTime? (DateString value)
        {
            if (string.IsNullOrEmpty(value?._value)) return null;

            if (DateTime.TryParse(value._value, out DateTime result))
            {
                return result;
            }
            throw new ArgumentException("非法的日期格式", nameof(value));
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateTime(DateString value)
        {
            if (string.IsNullOrEmpty(value?._value)) throw new ArgumentNullException(nameof(value));

            if (DateTime.TryParse(value._value, out DateTime result))
            {
                return result;
            }
            throw new ArgumentException("非法的日期格式", nameof(value));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _value;
        }
        /// <summary>
        /// 日期格式验证
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        public bool Valid(out string error)
        {
            error = string.Empty;
            try { DateTime? dateTime = this; return true; }
            catch (Exception ex) { error = ex.Message; return false; }
        }
    }
}