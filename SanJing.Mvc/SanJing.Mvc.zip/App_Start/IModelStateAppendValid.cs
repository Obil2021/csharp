﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$
{
    public interface IModelStateAppendValid
    {
        void Valid(ModelStateDictionary modelState);
    }
    /// <summary>
    /// 日期字符串
    /// </summary>
    public class DateString
    {
        private string _value;
        /// <summary>
        /// 
        /// </summary>
        public DateString() { _value = string.Empty; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        public DateString(string value) { _value = value ?? string.Empty; }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateString(string value)
        {
            return new DateString(value);
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateTime? (DateString value)
        {
            if (string.IsNullOrEmpty(value?._value)) return null;

            if (DateTime.TryParse(value._value, out DateTime result))
            {
                return result;
            }
            throw new ArgumentException("非法的日期格式", nameof(value));
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateString(DateTime? value)
        {
            if (value.HasValue) return new DateString(value.Value.ToString("yyyy-MM-dd"));
            return new DateString();
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateTime(DateString value)
        {
            if (string.IsNullOrEmpty(value?._value)) throw new ArgumentNullException(nameof(value));

            if (DateTime.TryParse(value._value, out DateTime result))
            {
                return result;
            }
            throw new ArgumentException("非法的日期格式", nameof(value));
        }
        /// <summary>
        /// 隐式自定义类型转换。
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static implicit operator DateString(DateTime value)
        {
            return new DateString(value.ToString("yyyy-MM-dd"));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _value;
        }
        /// <summary>
        /// 日期格式验证
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        public bool Valid(out string error)
        {
            error = string.Empty;
            try { DateTime? dateTime = this; return true; }
            catch (Exception ex) { error = ex.Message; return false; }
        }
    }
    /// <summary>
    /// Json序列化时间格式
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDateTimeFormat : Attribute
    {
        /// <summary>
        /// 
        /// </summary>
        public string Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="format"></param>
        public JsonDateTimeFormat(string format = SanJing.Const.DATE_YYYYMMDDHHMMSS)
        {
            Format = format;
        }
    }
}