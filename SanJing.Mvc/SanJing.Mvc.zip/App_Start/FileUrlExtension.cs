﻿using $safeprojectname$.Models.gen;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// 文件上传处理
    /// </summary>
    public class FileUrlExtension
    {
        /// <summary>
        /// 默认客户用户头像
        /// </summary>
        public const string DEFAULT_CLIENTER_USER_HEADR = "/content/head_man_client.jpg";

        /// <summary>
        /// 默认系统用户头像
        /// </summary>
        public const string DEFAULT_SYSTEM_USER_HEADR = "/content/head_man.jpg";

        /// <summary>
        /// 默认系统LOGO
        /// </summary>
        public const string DEFAULT_SYSTEM_LOGO = "/content/cd_2019.jpg";

        /// <summary>
        /// 文件路径转URL
        /// </summary>
        /// <param name="filename">文件路径</param>
        /// <returns></returns>
        public static string FileNameToUrl(string filename)
        {
            if (string.IsNullOrEmpty(filename)) return string.Empty;

            if (filename.StartsWith("/")) return HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) + filename;

            return filename;
        }
        /// <summary>
        /// URL转文件路径
        /// </summary>
        /// <param name="url">URL</param>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static bool UrlToFileName(string url, out string filename)
        {
            filename = string.Empty;
            if (string.IsNullOrEmpty(url)) return true;

            if (url.StartsWith("/"))
            {
                if (File.Exists(HttpContext.Current.Server.MapPath(url.Split('?')[0])))
                {
                    filename = url;
                    return true;
                }
            }
            else
            {
                try
                {
                    var uri = new Uri(url);
                    if (uri.GetLeftPart(UriPartial.Authority) == HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority))
                    {
                        filename = url.Replace(uri.GetLeftPart(UriPartial.Authority), string.Empty).Split('?')[0];
                        if (File.Exists(HttpContext.Current.Server.MapPath(filename)))
                            return true;
                    }
                    else
                    {
                        filename = url;//外部链接
                        return true;
                    }
                }
                catch { }
            }
            filename = string.Empty;
            return false;
        }
    }
}