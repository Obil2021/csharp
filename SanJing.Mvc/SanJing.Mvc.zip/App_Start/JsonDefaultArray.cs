﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// Json序列化集合默认值：空集合返回[]而不是null
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDefaultArray:Attribute
    {

    }
}