﻿using Newtonsoft.Json;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http.Filters;

namespace $safeprojectname$
{
    /// <summary>
    /// WEBAPI全局异常处理
    /// </summary>
    public sealed class WebApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        /// <summary>
        /// OnException
        /// </summary>
        /// <param name="actionExecutedContext"></param>
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            //记录
            var requestParams = HttpContext.Current.Request.Params;
            string jsonParams = JsonConvert.SerializeObject(requestParams.AllKeys.ToDictionary(k => k, k => requestParams[k]), Formatting.Indented);//请求实列

            HttpContext.Current.Request.InputStream.Position = 0;
            var requestContent = new StreamReader(HttpContext.Current.Request.InputStream, Encoding.UTF8).ReadToEnd();//请求内容
            NLogExtension.Error(actionExecutedContext.Exception.ToString(), requestContent, jsonParams);

            //返回 500
            actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(HttpStatusCode.OK, WebApiResult.Failed1500(new WebApiEmptyResult()));
        }
    }
}
