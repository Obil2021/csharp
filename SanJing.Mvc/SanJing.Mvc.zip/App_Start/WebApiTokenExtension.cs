﻿using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// Token验证
    /// </summary>
    public static class WebApiTokenExtansion
    {
        /// <summary>
        /// 存储到内存
        /// </summary>
        private static readonly List<TokenCache> TOKENS = new List<TokenCache>();
        /// <summary>
        /// 
        /// </summary>
        public const string TOKEN_NAME = "X-User-Token";
        /// <summary>
        /// 获取header中的X-User-Token并验证
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static bool TryGetUserId(this ApiController apiController, out int userid)
        {
            //读取header
            userid = 0;
            if (!apiController.Request.Headers.TryGetValues(TOKEN_NAME, out IEnumerable<string> header)) return false;

            //是否为空
            var tokenStr = HttpUtility.UrlDecode(header.Single());
            if (string.IsNullOrWhiteSpace(tokenStr)) return false;

            var cache = TOKENS.SingleOrDefault(q => q.Token == tokenStr);

            if (cache == null)
                return false;
            userid = cache.UserId;
            return true;
        }
        /// <summary>
        /// 根据用户账户生成Token
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static string UserIdToToken(int userid)
        {
            //有效期
            var token = Guid.NewGuid().ToString("N");
            TOKENS.Add(new TokenCache()
            {
                Token = token,
                UserId = userid
            });

            //存储
            CacheSave();
            return token;
        }
        /// <summary>
        /// 根据用户账户生成Token[唯一]
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static string UserIdToTokenOnly(int userid)
        {
            //有效期
            var token = Guid.NewGuid().ToString("N");

            var cache = TOKENS.SingleOrDefault(q => q.UserId == userid);

            if (cache == null)
            {
                TOKENS.Add(new TokenCache()
                {
                    Token = token,
                    UserId = userid
                });
            }
            else
            {
                cache.Token = token;
            }

            //存储
            CacheSave();
            return token;
        }
        /// <summary>
        /// 加载缓存
        /// </summary>
        public static void CacheLoad()
        {
            var cache = System.Web.HttpRuntime.BinDirectory.Substring(0, System.Web.HttpRuntime.BinDirectory.Length - 4) + "syscaches";
            if (!System.IO.Directory.Exists(cache))
            {
                System.IO.Directory.CreateDirectory(cache);
            }
            var cachetokens = $"{cache}/tokens.json";

            if (System.IO.File.Exists(cachetokens))
            {
                try
                {
                    var json = System.IO.File.ReadAllText(cachetokens, System.Text.Encoding.UTF8);
                    var temp = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TokenCache>>(json);

                    lock (TOKENS)
                    {
                        TOKENS.Clear();

                        foreach (var item in temp)
                        {
                            TOKENS.Add(item);
                        }
                    }
                }
                catch { }
            }
        }
        /// <summary>
        /// 存储缓存
        /// </summary>
        private static void CacheSave()
        {
            var cache = HttpRuntime.BinDirectory.Substring(0, System.Web.HttpRuntime.BinDirectory.Length - 4) + "syscaches";
            if (!System.IO.Directory.Exists(cache))
            {
                System.IO.Directory.CreateDirectory(cache);
            }
            var cachetokens = $"{cache}/tokens.json";

            var temp = TOKENS.Where(q => q.Timestamp > DateTime.Now.ToUnixTimestamp()).ToList();//去掉无效的

            lock (TOKENS)
            {
                TOKENS.Clear();

                foreach (var item in temp)
                {
                    TOKENS.Add(item);
                }
            }

            var json = Newtonsoft.Json.JsonConvert.SerializeObject(TOKENS);

            System.IO.File.WriteAllText(cachetokens, json, encoding: System.Text.Encoding.UTF8);
        }
    }
    /// <summary>
    /// 凭据缓存
    /// </summary>
    public class TokenCache
    {
        /// <summary>
        /// ID
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// TOKEN
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// 到期时间
        /// </summary>
        public long Timestamp { get; private set; } = DateTime.Now.AddDays(7).ToUnixTimestamp();//有效期7天
    }
}