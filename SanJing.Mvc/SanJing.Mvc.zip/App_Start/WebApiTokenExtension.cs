﻿using $safeprojectname$.Models.gen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// Token验证
    /// </summary>
    public static class WebApiTokenExtansion
    {
        /// <summary>
        /// 有效期
        /// </summary>
        public const int expire = 60 * 24 * 7;
        /// <summary>
        /// HEADER字段名称
        /// </summary>
        public const string TOKEN_NAME = "X-User-Token";
        /// <summary>
        /// 获取header中的X-User-Token并验证
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static bool TryGetUserId(this ApiController apiController, out int userid)
        {
            //读取header
            userid = 0;
            var tokenStr = HttpContext.Current.Request.Cookies[TOKEN_NAME]?.Value;//session中读取
            if (string.IsNullOrWhiteSpace(tokenStr))//session中不存在
            {
                if (apiController.Request.Headers.TryGetValues(TOKEN_NAME, out IEnumerable<string> header)) //header中存在
                {
                    tokenStr = HttpUtility.UrlDecode(header.First()); //header中读取
                    if (string.IsNullOrWhiteSpace(tokenStr)) return false;//header中不存在
                }
                else
                    return false;
            }
            if (SanJing.Cache.ReadAs(tokenStr, SanJing.Cache.ID_TOKEN, out string val))
            {
                if (int.TryParse(val, out userid))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// 根据用户账户生成Token并储到Session中
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static string UserIdToToken(int userid)
        {
            var token = Guid.NewGuid().ToString("N");
            SanJing.Cache.SaveAs(token, userid.ToString(), expire, SanJing.Cache.ID_TOKEN);//有效期7天
            HttpContext.Current.Response.Cookies.Add(new HttpCookie(TOKEN_NAME, token));
            return token;
        }
        /// <summary>
        /// 根据用户账户清除Token
        /// </summary>
        /// <param name="userid"></param>
        public static void Clear(int userid)
        {
            SanJing.Cache.Clear(SanJing.Cache.ID_TOKEN, userid.ToString());
        }
    }
}