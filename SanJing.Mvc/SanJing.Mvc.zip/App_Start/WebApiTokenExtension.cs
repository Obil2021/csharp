﻿using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// Token验证
    /// </summary>
    public static class WebApiTokenExtansion
    {
        /// <summary>
        /// 有效期
        /// </summary>
        public const int expire = 60 * 24 * 7;
        /// <summary>
        /// HEADER字段名称
        /// </summary>
        public const string TOKEN_NAME = "X-User-Token";
        /// <summary>
        /// 获取header中的X-User-Token并验证
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static bool TryGetUserId(this ApiController apiController, out int userid)
        {
            //读取header
            userid = 0;
            if (!apiController.Request.Headers.TryGetValues(TOKEN_NAME, out IEnumerable<string> header)) return false;

            //是否为空
            var tokenStr = HttpUtility.UrlDecode(header.Single());
            if (string.IsNullOrWhiteSpace(tokenStr)) return false;

            if(SanJing.Cache.ReadAs(tokenStr,SanJing.Cache.ID_TOKEN, out string val))
            {
                if(int.TryParse(val,out userid))
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// 根据用户账户生成Token
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static string UserIdToToken(int userid)
        {
            var token = Guid.NewGuid().ToString("N");
            SanJing.Cache.SaveAs(token, userid.ToString(), expire, SanJing.Cache.ID_TOKEN);//有效期7天
            return token;
        }
        /// <summary>
        /// 根据用户账户生成Token[唯一]
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static string UserIdToTokenOnly(int userid)
        {
            SanJing.Cache.Clear(SanJing.Cache.ID_TOKEN, userid.ToString());

            var token = Guid.NewGuid().ToString("N");
            SanJing.Cache.SaveAs(token, userid.ToString(), expire, SanJing.Cache.ID_TOKEN);//有效期7天
            return token;
        }
    }
}