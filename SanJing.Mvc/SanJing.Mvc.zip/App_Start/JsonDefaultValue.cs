﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// Json序列化默认值
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class JsonDefaultValue : Attribute
    {
        /// <summary>
        /// 默认值
        /// </summary>
        public object Value { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="value">默认值</param>
        public JsonDefaultValue(object value)
        {
            Value = value;
        }
    }
    /// <summary>
    /// Json序列化默认值[string.Empty]
    /// </summary>
    public class JsonDefaultString: JsonDefaultValue
    {
        /// <summary>
        /// 初始化
        /// </summary>
        public JsonDefaultString() : base(string.Empty)
        {

        }
    }
}