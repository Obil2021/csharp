﻿using Newtonsoft.Json;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace $safeprojectname$
{
    /// <summary>
    /// MVC全局异常处理
    /// </summary>
    internal sealed class MvcHandleErrorAttribute : HandleErrorAttribute
    {
        /// <summary>
        /// OnException
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnException(ExceptionContext filterContext)
        {
            //数据库验证异常
            if (filterContext.Exception is DbEntityValidationException)
            {
                var ex = filterContext.Exception as DbEntityValidationException;
                if (ex.EntityValidationErrors.Count() > 0)
                    filterContext.Exception = new System.Exception(string.Join(";",
                        ex.EntityValidationErrors.SelectMany(q => q.ValidationErrors.Select(w => $"{w.PropertyName}:{w.ErrorMessage}"))), ex);
            }

            //记录
            var requestParams = filterContext.HttpContext.Request.Params;
            string jsonParams = JsonConvert.SerializeObject(requestParams.AllKeys.ToDictionary(k => k, k => requestParams[k]), Formatting.Indented);//请求实列

            filterContext.HttpContext.Request.InputStream.Position = 0;
            var requestContent = new StreamReader(filterContext.HttpContext.Request.InputStream, Encoding.UTF8).ReadToEnd();//请求内容
            NLogExtension.Error(filterContext.Exception.ToString(), requestContent, jsonParams);

            //导航到错误页
            filterContext.ExceptionHandled = true;
            filterContext.Result = new HttpStatusCodeResult(System.Net.HttpStatusCode.InternalServerError);

            //base.OnException(filterContext);
        }
    }
}