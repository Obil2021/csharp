﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// 日志扩展
    /// </summary>
    public static class NLogExtension
    {
        /// <summary>
        /// 错误日期含JSON
        /// </summary>
        /// <param name="api"></param>
        /// <param name="text"></param>
        /// <param name="json"></param>
        public static void NlogInfo(this ApiController api,string text,params string[] json)
        {
            Info(text, json);
        }
        /// <summary>
        /// 错误日期含JSON
        /// </summary>
        /// <param name="text"></param>
        /// <param name="json"></param>
        public static void Error(string text, params string[] json)
        {
            if (string.IsNullOrWhiteSpace(text)) return;

            text = text.Replace(Environment.NewLine, "</p><p>");

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.Append("<div style='color:#dc3545!important'>");
            htmlCode.Append("<p>");
            htmlCode.Append(text);
            htmlCode.Append("</p>");
            htmlCode.Append("</div>");

            foreach (var item in json)
            {
                if (string.IsNullOrWhiteSpace(item)) continue;

                htmlCode.Append("<pre>");
                htmlCode.Append("<code style='color:#6c757d!important'>");
                htmlCode.Append(item);
                htmlCode.Append("</code>");
                htmlCode.Append("</pre>");
            }
            NLog.LogManager.GetCurrentClassLogger().Error(htmlCode);
        }
        /// <summary>
        /// 信息日志含JSON
        /// </summary>
        /// <param name="text"></param>
        /// <param name="json"></param>
        public static void Info(string text, params string[] json)
        {
            if (string.IsNullOrWhiteSpace(text)) return;

            text = text.Replace(Environment.NewLine, "</p><p>");

            StringBuilder htmlCode = new StringBuilder();
            htmlCode.Append("<div style='color:#17a2b8!important'>");
            htmlCode.Append("<p>");
            htmlCode.Append(text);
            htmlCode.Append("</p>");
            htmlCode.Append("</div>");
            foreach (var item in json)
            {
                if (string.IsNullOrWhiteSpace(item)) continue;

                htmlCode.Append("<pre>");
                htmlCode.Append("<code style='color:#6c757d!important'>");
                htmlCode.Append(item);
                htmlCode.Append("</code>");
                htmlCode.Append("</pre>");
            }

            NLog.LogManager.GetCurrentClassLogger().Info(htmlCode);
        }
    }
}