﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// WebApiConfig
    /// </summary>
    public static class WebApiConfig
    {
        /// <summary>
        /// Register
        /// </summary>
        /// <param name="config"></param>
        public static void Register(HttpConfiguration config)
        {
            //接口V1
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/v1/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //接口pay
            config.Routes.MapHttpRoute(
                name: "DefaultApipay",
                routeTemplate: "api/pay/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //接口V2
            //config.Routes.MapHttpRoute(
            //    name: "DefaultApiv2",
            //    routeTemplate: "api/v2/{controller}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            //);

            // 移除XML序列化器
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            //全局异常处理
            config.Filters.Add(new WebApiExceptionFilterAttribute());
        }
    }
}
