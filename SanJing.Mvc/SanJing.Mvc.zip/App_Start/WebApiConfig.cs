﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.Dispatcher;

namespace $safeprojectname$
{
    /// <summary>
    /// WebApiConfig
    /// </summary>
    public static class WebApiConfig
    {
        /// <summary>
        /// Register
        /// </summary>
        /// <param name="config"></param>
        public static void Register(HttpConfiguration config)
        {
            //接口GEN
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/gen/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //接口APP
            config.Routes.MapHttpRoute(
                name: "APPApi",
                routeTemplate: "api/app/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //接口APP
            config.Routes.MapHttpRoute(
                name: "CMSApi",
                routeTemplate: "api/cms/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //全局异常处理
            config.Filters.Add(new WebApiExceptionFilterAttribute());

            // 移除XML序列化器
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            // 解决json序列化时的循环引用问题
            config.Formatters.JsonFormatter.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            // json日期格式
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatHandling = Newtonsoft.Json.DateFormatHandling.MicrosoftDateFormat;
            config.Formatters.JsonFormatter.SerializerSettings.DateFormatString = SanJing.Const.DATE_YYYYMMDDHHMMSS;
            //json 字符串为null
            config.Formatters.JsonFormatter.SerializerSettings.ContractResolver = new WebApiJsonContractResolver();

        }
    }
}
