﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// 支付回调
    /// </summary>
    public static class PayExtansion
    {
        /// <summary>
        /// 微信APPID
        /// </summary>
        public static readonly string WX_APPID = "";
        /// <summary>
        /// 微信商户ID
        /// </summary>
        public static readonly string WX_MCHID = "";
        /// <summary>
        /// 微信商户KEY
        /// </summary>
        public static readonly string WX_MCHKEY = "";
        /// <summary>
        /// 支付宝APPID
        /// </summary>
        public static readonly string ZFB_APPID = "";
        /// <summary>
        /// 支付宝私钥文件地址
        /// </summary>
        public static readonly string ZFB_PRIKEY_PATH = "/alipay/xxx.pem";
        /// <summary>
        /// 支付宝公钥
        /// </summary>
        public static readonly string ZFB_PUBKEY = "";
        /// <summary>
        /// 获取支付宝私钥完整路径
        /// </summary>
        /// <param name="apiController"></param>
        /// <returns></returns>
        public static string GetFullZFB_PRIKEY_PATH(this ApiController apiController)
        {
            return HttpContext.Current.Server.MapPath(ZFB_PRIKEY_PATH);
        }
        /// <summary>
        /// 获取当前服务器IP地址
        /// </summary>
        /// <param name="apiController"></param>
        /// <returns></returns>
        public static string GetServerIPAddress(this ApiController apiController)
        {
            return HttpContext.Current.Request.Params["LOCAL_ADDR"];
        }
        /// <summary>
        /// 获取微信回调地址
        /// </summary>
        /// <param name="apiController"></param>
        /// <returns></returns>
        public static string GetWeixinCallbackURL(this ApiController apiController)
        {
            return apiController.Request.RequestUri.GetLeftPart(UriPartial.Authority) + "/api/pay/wxcallback";
        }
        /// <summary>
        /// 获取支付宝回调地址
        /// </summary>
        /// <param name="apiController"></param>
        /// <returns></returns>
        public static string GetZhifubaoCallbackURL(this ApiController apiController)
        {
            return apiController.Request.RequestUri.GetLeftPart(UriPartial.Authority) + "/api/pay/zfbcallback";
        }
    }
}