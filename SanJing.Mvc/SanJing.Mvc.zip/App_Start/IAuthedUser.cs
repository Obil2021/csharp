﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    public interface IAuthedUser
    {
        bool Authed(int userid, int authCode);
    }
}