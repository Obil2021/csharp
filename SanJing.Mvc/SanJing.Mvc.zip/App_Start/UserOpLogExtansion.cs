﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// 用户操作日志
    /// </summary>
    public static class UserOpLogExtansio
    {
        /// <summary>
        /// 执行数据库操作并保存日志
        /// </summary>
        /// <param name="db"></param>
        /// <param name="userid"></param>
        /// <param name="request"></param>
        /// <param name="hides">内容中需要隐藏字符串</param>
        public static void SaveChangesWithLog<Req, Db>(this Db db, int userid, Req request, params string[] hides)
            where Db : System.Data.Entity.DbContext, new()
            where Req : UserLogModel
        {
            string content = request.UserLogContent();

            foreach (var item in hides)
            {
                content = content.Replace(item, "******");
            }

            //db.UserLog.Add(new DbEF.UserLog()
            //{
            //    UserId = userid,
            //    DateTime = DateTime.Now,
            //    IPAddress = HttpContext.Current.Request.UserHostAddress ?? "未知",
            //    Content = content,
            //    Title = request.UserLogTitle(),
            //    Role = request.Role()
            //});

            //db.SaveChanges();
        }
    }
    /// <summary>
    /// 用户日志基类
    /// </summary>
    public abstract class UserLogModel
    {
        /// <summary>
        /// 标题
        /// </summary>
        /// <returns></returns>
        public abstract string UserLogTitle();
        /// <summary>
        /// 内容
        /// </summary>
        /// <returns></returns>
        public virtual string UserLogContent()
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }
        /// <summary>
        /// 类型
        /// </summary>
        /// <returns></returns>
        public virtual int Role()
        {
            return 0;
        }
    }
    /// <summary>
    /// 客户用户日志基类
    /// </summary>
    public abstract class ClienterUserLogModel : UserLogModel
    {
        /// <summary>
        /// 类型
        /// </summary>
        /// <returns></returns>
        public override int Role()
        {
            return 1;
        }
    }
}