﻿using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    /// <summary>
    /// 默认返回状态码设置
    /// </summary>
    class SwaggerHttpOperationFilter : IOperationFilter
    {
        /// <summary>
        /// 默认返回状态码设置
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, System.Web.Http.Description.ApiDescription apiDescription)
        {
            if (operation.responses == null)
                operation.responses = new Dictionary<string, Response>();

            if (operation.parameters == null)
                operation.parameters = new List<Parameter>();

            if (operation.consumes == null)
                operation.consumes = new List<string>();

            foreach (var item in operation.parameters)
            {
                if (string.IsNullOrEmpty(item.name))
                    continue;
                if (item.name.Trim('.').Contains('.'))
                {
                    item.name = item.name.Substring(item.name.IndexOf('.') + 1);//去掉GET请求的URL参数名中的类型名称
                }
            }

            //1401 需要身份验证
            if (operation.operationId == SwaggerOperationId.TOKEN_AUTH)
            {
                operation.parameters.Add(new Parameter
                {
                    name = WebApiHeaderExtansion.TOKEN_NAME,
                    @in = "header",
                    type = "string",
                    description = "用户凭据【TOKEN】",
                    required = true
                });
            }
            else if (operation.operationId == SwaggerOperationId.FILE_UPLOAD)
            {
                operation.consumes.Add("multipart/form-data");
                operation.parameters.Add(new Parameter
                {
                    name = "file",
                    @in = "formData",
                    type = "file",
                    description = "multipart/form-data",
                    required = true
                });
            }
        }
    }

    /// <summary>
    /// SwaggerOperationId
    /// </summary>
    public class SwaggerOperationId
    {
        /// <summary>
        /// 文件上传
        /// </summary>
        public const string FILE_UPLOAD = "FILE_UPLOAD";
        /// <summary>
        /// 身份验证
        /// </summary>
        public const string TOKEN_AUTH = "TOKEN_AUTH";
    }
}
