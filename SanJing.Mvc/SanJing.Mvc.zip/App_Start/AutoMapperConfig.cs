﻿using AutoMapper;
using $safeprojectname$.Mappers.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// AutoMapperConfig
    /// </summary>
    public class AutoMapperConfig
    {
        /// <summary>
        /// 
        /// </summary>
        public static void Config()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfiles(AppDomain.CurrentDomain.GetAssemblies().Where(q=>q.FullName.StartsWith(typeof(AutoMapperConfig).Namespace)));//当前项目程序集
            });

            //在程序启动时对所有的配置进行严格的验证
            Mapper.AssertConfigurationIsValid();
        }
    }
}