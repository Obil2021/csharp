﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    /// <summary>
    /// 对分页数据的查询请求模型
    /// </summary>
    public class WebApiPageRequest
    {
        /// <summary>
        /// 搜索词
        /// </summary>
        public virtual string SerachKey { get; set; }

        /// <summary>
        /// 页码
        /// </summary>
        [Range(1, int.MaxValue)]
        public virtual int PageNum { get; set; }
    }
    /// <summary>
    /// 对单个数据查询或操作的请求模型
    /// </summary>
    public class WebApiIdRequest
    {
        /// <summary>
        /// 唯一标识
        /// </summary>
        [Range(1, int.MaxValue)]
        public virtual int Id { get; set; }
    }
}