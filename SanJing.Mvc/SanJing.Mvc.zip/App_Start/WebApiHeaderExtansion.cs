﻿using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// Token验证
    /// </summary>
    public static class WebApiHeaderExtansion
    {
        /// <summary>
        /// 
        /// </summary>
        public const string TOKEN_NAME = "X-User-Token";
        /// <summary>
        /// 获取header中的X-User-Token并验证
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static bool TryGetUserId(this ApiController apiController, out int userid)
        {
            //读取header
            userid = 0;
            IEnumerable<string> header;
            if (!apiController.Request.Headers.TryGetValues(TOKEN_NAME, out header)) return false;

            //是否为空
            var tokenStr = HttpUtility.UrlDecode(header.Single());
            if (string.IsNullOrWhiteSpace(tokenStr)) return false;

            var expire = DateTime.Now.ToUnixTimestamp();

            using (var db = new DbEF.Entities())
            {
                var tokencache = db.TokenCache.AsNoTracking().SingleOrDefault(q => q.Token == tokenStr && q.Expire > expire);

                if (tokencache != null)
                {
                    //返回账户
                    userid = tokencache.UserId;
                    return true;
                }
            }

            return false;
        }
        /// <summary>
        /// 根据用户账户生成Token
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <param name="role">用户类型【0系统，1客户】</param>
        /// <returns></returns>
        public static string UserIdToToken(int userid, int role = 0)
        {
            //有效期
            var expire = DateTime.Now.AddDays(7).ToUnixTimestamp();
            var token = Guid.NewGuid().ToString("N");
            var isonly = false;//是否唯一登录
            using (var db = new DbEF.Entities())
            {
                if (isonly)
                {
                    var tokencache = db.TokenCache.SingleOrDefault(q => q.UserId == userid && q.Role == role);

                    if (tokencache != null)
                    {
                        tokencache.Token = token;
                        tokencache.Expire = expire;
                    }
                    else
                    {
                        db.TokenCache.Add(new DbEF.TokenCache()
                        {
                            Expire = expire,
                            Role = role,
                            UserId = userid,
                            Token = token
                        });
                    }
                }
                else
                {
                    db.TokenCache.Add(new DbEF.TokenCache()
                    {
                        Expire = expire,
                        Role = role,
                        UserId = userid,
                        Token = token
                    });
                }
                db.SaveChanges();
            }

            return token;
        }
    }
}