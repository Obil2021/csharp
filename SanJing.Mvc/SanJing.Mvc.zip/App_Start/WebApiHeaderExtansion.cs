﻿using $safeprojectname$.Models.v1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace $safeprojectname$
{
    /// <summary>
    /// Token验证
    /// </summary>
    public static class WebApiHeaderExtansion
    {
        /// <summary>
        /// 
        /// </summary>
        public static readonly string TOKEN_NAME = "X-User-Token";
        /// <summary>
        /// 
        /// </summary>
        public static readonly string DEVICE_NAME = "X-Device-OS";
        /// <summary>
        /// 获取header中的X-Device-OS并验证
        /// </summary>
        /// <returns></returns>
        public static bool TryGetOSName(this ApiController apiController, out OSName os)
        {
            os = OSName.unknown;
            IEnumerable<string> header;
            if (!apiController.Request.Headers.TryGetValues(DEVICE_NAME, out header)) return false;
            try
            {
                os = (OSName)Enum.Parse(typeof(OSName), header.Single());
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 获取header中的X-User-Token并验证
        /// </summary>
        /// <param name="apiController"></param>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static bool TryGetUserId(this ApiController apiController, out string userid)
        {
            //读取header
            userid = string.Empty;
            IEnumerable<string> header;
            if (!apiController.Request.Headers.TryGetValues(TOKEN_NAME, out header)) return false;

            try
            {
                //是否为空
                var tokenStr = HttpUtility.UrlDecode(header.Single());
                if (string.IsNullOrWhiteSpace(tokenStr)) return false;

                //解密
                var json = SanJing.Hash.Decrypt.AES128(tokenStr);
                var token = Newtonsoft.Json.JsonConvert.DeserializeObject<TokenModel>(json);

                //过期
                if (Convert.ToDateTime(token.Expire) < DateTime.Now)
                {
                    return false;
                }

                //返回账户
                userid = token.Token;
                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 根据用户账户生成Token
        /// </summary>
        /// <param name="userid">用户标识</param>
        /// <returns></returns>
        public static TokenModel UserIdToToken(string userid)
        {
            //有效期
            var expire = DateTime.Now.AddDays(7).ToString("yyyy-MM-dd HH:mm:ss");

            //加密
            var res = new TokenModel() { Token = userid, Expire = expire };
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(res);
            res.Token = HttpUtility.UrlEncode(SanJing.Hash.Encrypt.AES128(json));

            return res;
        }
    }
    /// <summary>
    /// 系统类型
    /// </summary>
    public enum OSName
    {
        /// <summary>
        /// 未知
        /// </summary>
        unknown,
        /// <summary>
        /// 苹果APP
        /// </summary>
        ios,
        /// <summary>
        /// 安卓APP
        /// </summary>
        android,
        /// <summary>
        /// PC端网页
        /// </summary>
        web,
        /// <summary>
        /// 移动端网页
        /// </summary>
        h5,
        /// <summary>
        /// 微信公众号
        /// </summary>
        wxh5,
        /// <summary>
        /// 微信小程序
        /// </summary>
        wxapp
    }
    /// <summary>
    /// TOKEN模型
    /// </summary>
    public class TokenModel
    {
        /// <summary>
        /// TOKEN值
        /// </summary>
        public string Token { get; set; } = string.Empty;
        /// <summary>
        /// 到期时间
        /// </summary>
        public string Expire { get; set; } = string.Empty;
    }
}