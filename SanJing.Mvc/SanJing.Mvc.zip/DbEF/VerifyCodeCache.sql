USE [Db]
GO

/****** Object:  Table [dbo].[VerifyCodeCache]    Script Date: 2020/1/1 22:17:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VerifyCodeCache](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PhoneNum] [varchar](50) NOT NULL,
	[VerifyCode] [char](6) NOT NULL,
	[Expire] [datetime] NOT NULL,
 CONSTRAINT [PK_VerifyCodeCache] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VerifyCodeCache', @level2type=N'COLUMN',@level2name=N'Id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ֻ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VerifyCodeCache', @level2type=N'COLUMN',@level2name=N'PhoneNum'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��֤��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VerifyCodeCache', @level2type=N'COLUMN',@level2name=N'VerifyCode'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VerifyCodeCache', @level2type=N'COLUMN',@level2name=N'Expire'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��֤�뻺��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VerifyCodeCache'
GO


