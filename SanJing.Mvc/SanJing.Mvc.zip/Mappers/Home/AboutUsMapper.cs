﻿
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Mappers.Home
{
    /// <summary>
    /// 
    /// </summary>
    public class AboutUsMapper : Profile
    {
        /// <summary>
        /// 数据映射
        /// </summary>
        public AboutUsMapper()
        {
            CreateMap<DbEF.SystemUser, Models.User.LoginModel>().ForMember(c => c.Password, q =>
            {
                q.MapFrom(z => "******");
            });
        }
    }
}