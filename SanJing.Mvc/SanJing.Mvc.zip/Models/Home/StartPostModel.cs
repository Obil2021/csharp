﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.Home
{
    /// <summary>
    /// 
    /// </summary>
    public class StartPostModel
    {
        /// <summary>
        /// 文件地址
        /// </summary>
        [Required]
        public string FileUrl { get; set; }
    }
}