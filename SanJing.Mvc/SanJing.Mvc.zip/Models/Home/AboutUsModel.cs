﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.Home
{
    /// <summary>
    /// 关于我们模型
    /// </summary>
    public class AboutUsModel
    {
        /// <summary>
        /// 内容
        /// </summary>
        [Display(Name = "关于我们")]
        [Required]
        public string Content { get; set; }
    }
}