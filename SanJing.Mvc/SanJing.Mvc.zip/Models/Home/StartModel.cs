﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.Home
{
    /// <summary>
    /// 起始页模型
    /// </summary>
    public class StartModel
    {
        /// <summary>
        /// 全部收入
        /// </summary>
        public string IncomeAll { get; set; }
        /// <summary>
        /// 本年收入
        /// </summary>
        public string IncomeYear { get; set; }
        /// <summary>
        /// 本月收入
        /// </summary>
        public string IncomeMonth { get; set; }
        /// <summary>
        /// 本日收入
        /// </summary>
        public string IncomeDay { get; set; }
        /// <summary>
        /// 全部订单
        /// </summary>
        public string OrderAll { get; set; }
        /// <summary>
        /// 本年订单
        /// </summary>
        public string OrderYear { get; set; }
        /// <summary>
        /// 本月订单
        /// </summary>
        public string OrderMonth { get; set; }
        /// <summary>
        /// 本日订单
        /// </summary>
        public string OrderDay { get; set; }
        /// <summary>
        /// 全部用户
        /// </summary>
        public string UserAll { get; set; }
        /// <summary>
        /// 本年用户
        /// </summary>
        public string UserYear { get; set; }
        /// <summary>
        /// 本月用户
        /// </summary>
        public string UserMonth { get; set; }
        /// <summary>
        /// 本日用户
        /// </summary>
        public string UserDay { get; set; }

        /// <summary>
        /// 课题
        /// </summary>
        public string WordSubject { get; set; }
        /// <summary>
        /// 章节
        /// </summary>
        public string WordChapter { get; set; }
        /// <summary>
        /// 单词
        /// </summary>
        public string WordAll { get; set; }
    }
}