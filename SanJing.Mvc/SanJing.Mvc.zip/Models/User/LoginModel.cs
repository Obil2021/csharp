﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.User
{
    /// <summary>
    /// 系统用户登录模型
    /// </summary>
    public class LoginModel : UserLogModel
    {
        /// <summary>
        /// 账户
        /// </summary>
        [Required]
        [StringLength(18, MinimumLength = 5)]
        public virtual string Account { get; set; }
        /// <summary>
        /// 密码【SHA1】
        /// </summary>
        [Required]
        [StringLength(18, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public virtual string Password { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string UserLogTitle()
        {
            return "用户登录";
        }
    }
}