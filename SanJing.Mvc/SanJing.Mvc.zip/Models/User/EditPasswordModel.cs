﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Models.User
{
    /// <summary>
    /// 修改密码模型
    /// </summary>
    public class EditPasswordModel : UserLogModel
    {
        /// <summary>
        /// 旧密码
        /// </summary>
        [Required]
        [Display(Name = "旧密码")]
        [StringLength(18, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string OldPassword { get; set; }
        /// <summary>
        /// 新密码
        /// </summary>
        [Required]
        [Display(Name = "新密码")]
        [StringLength(18, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }
        /// <summary>
        /// 重复新密码
        /// </summary>
        [Required]
        [Display(Name = "重复新密码")]
        [StringLength(18, MinimumLength = 6)]
        [Compare("NewPassword")]
        [DataType(DataType.Password)]
        public string RepeatPassword { get; set; }
        /// <summary>
        /// UserLogTitle
        /// </summary>
        /// <returns></returns>
        public override string UserLogTitle()
        {
            return "修改密码";
        }
    }
}