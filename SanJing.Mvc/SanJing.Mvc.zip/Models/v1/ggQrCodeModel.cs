﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 生成二维码
    /// </summary>
    public class ggQrCodeModel
    {
        /// <summary>
        /// 请求模型
        /// </summary>
        public class Req
        {
            /// <summary>
            /// 二维码内容
            /// </summary>
            [Required]
            public string Content { get; set; }
        }
        /// <summary>
        /// 返回模型
        /// </summary>
        public class Res
        {
            /// <summary>
            /// 二维码图片地址
            /// </summary>
            public ImageUrl QrCodeUrl { get; set; }
        }
    }
}