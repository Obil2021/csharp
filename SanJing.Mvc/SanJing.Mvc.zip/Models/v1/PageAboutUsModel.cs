﻿namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 关于我们
    /// </summary>
    public class PageAboutUsModel
    {
        /// <summary>
        /// GET返回
        /// </summary>
        public class GetResponse
        {
            /// <summary>
            /// 关于我们的页面地址
            /// </summary>
            public string AboutAsURL { get; set; } = string.Empty;
        }
    }
}