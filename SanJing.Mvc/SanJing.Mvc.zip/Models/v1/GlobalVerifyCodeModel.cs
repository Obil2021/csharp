﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局验证码
    /// </summary>
    public class GlobalVerifyCodeModel
    {
        /// <summary>
        /// POST请求
        /// </summary>
        public class PostRequest
        {
            /// <summary>
            /// 手机号码
            /// </summary>
            [Required]
            [DataType(DataType.PhoneNumber)]
            [StringLength(11, MinimumLength = 11)]
            public string PhoneNum { get; set; }
            /// <summary>
            /// 用途|注册时上传“REGISTER”固定值，登陆时上传“LOGIN”固定值
            /// </summary>
            [Required]
            public string UseType { get; set; }
            /// <summary>
            /// UseType数据验证
            /// </summary>
            /// <returns></returns>
            public bool UseTypeValdate()
            {
                return UseType == "LOGIN" || UseType == "REGISTER";
            }
            /// <summary>
            /// 是否是LOGIN
            /// </summary>
            /// <returns></returns>
            public bool UseTypeIsLogin()
            {
                return UseType == "LOGIN";
            }
        }
    }
}