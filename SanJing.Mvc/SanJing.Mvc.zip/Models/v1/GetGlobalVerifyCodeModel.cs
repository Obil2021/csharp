﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局验证码
    /// </summary>
    public class GetGlobalVerifyCodeModel
    {
        /// <summary>
        /// POST请求
        /// </summary>
        public class Req : IModelStateAppendValid
        {
            /// <summary>
            /// 手机号码
            /// </summary>
            [Required]
            [RegularExpression(Regular.NUM)]
            [StringLength(11, MinimumLength = 11)]
            public string PhoneNum { get; set; }

            public void Valid(ModelStateDictionary modelState)
            {
                if (!SanJing.SMS.Phone.IsValid(PhoneNum))
                    modelState.AddModelError(nameof(PhoneNum), "手机号不存在！");
            }
        }
    }
}