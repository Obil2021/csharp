﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局验证码
    /// </summary>
    public class GetGlobalVerifyCodeModel
    {
        /// <summary>
        /// POST请求
        /// </summary>
        public class Req
        {
            /// <summary>
            /// 手机号码
            /// </summary>
            [Required]
            [DataType(DataType.PhoneNumber)]
            [StringLength(11, MinimumLength = 11)]
            public string PhoneNum { get; set; }
        }
    }
}