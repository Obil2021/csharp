﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 登录
    /// </summary>
    public class PageLoginModel
    {
        /// <summary>
        /// POST请求
        /// </summary>
        public class PostRequest : ClienterUserLogModel
        {
            /// <summary>
            /// 手机号
            /// </summary>
            [Required]
            [DataType(DataType.PhoneNumber)]
            [StringLength(11, MinimumLength = 11)]
            public virtual string PhoneNum { get; set; }
            /// <summary>
            /// 短信验证码
            /// </summary>
            [Required]
            [StringLength(6, MinimumLength = 6)]
            public virtual string VerifyCode { get; set; }
            /// <summary>
            /// 
            /// </summary>
            /// <returns></returns>
            public override string UserLogTitle()
            {
                return "用户登录";
            }
        }
        /// <summary>
        /// GET返回
        /// </summary>
        public class GetResponse
        {
            /// <summary>
            /// 用户协议URL
            /// </summary>
            public string UserAgreementURL { get; set; } = string.Empty;

            /// <summary>
            /// 隐私策略URL
            /// </summary>
            public string PrivacyPolicyURL { get; set; } = string.Empty;
        }

        /// <summary>
        /// POST返回
        /// </summary>
        public class PostResponse
        {
            /// <summary>
            /// 用户凭据|有效期为7天
            /// </summary>
            [Required]
            [DataType(DataType.Password)]
            public string Token { get; set; } = string.Empty;
            /// <summary>
            /// 到期时间|请在到期时间之前换取新Tokrn
            /// </summary>
            [Required]
            [DataType(DataType.DateTime)]
            public string Expire { get; set; } = string.Empty;
            /// <summary>
            /// 转换
            /// </summary>
            /// <param name="token"></param>
            public void CopyFromTokenModel(TokenModel token)
            {
                this.Token = token.Token;
                this.Expire = token.Expire;
            }
        }
    }
}