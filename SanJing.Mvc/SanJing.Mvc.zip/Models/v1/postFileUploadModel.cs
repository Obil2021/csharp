﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局文件上传
    /// </summary>
    public class postFileUploadModel
    {
        /// <summary>
        /// POST返回
        /// </summary>
        public class Res
        {
            /// <summary>
            /// 文件完整URL地址【用于显示】
            /// </summary>
            public string FileUrl { get; set; }
            /// <summary>
            /// 文件相对URL地址【用于提交】
            /// </summary>
            public string FileId { get; set; }
        }
    }
}