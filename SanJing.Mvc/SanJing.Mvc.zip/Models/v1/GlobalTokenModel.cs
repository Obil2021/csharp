﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局凭据
    /// </summary>
    public class GlobalTokenModel
    {
        /// <summary>
        /// POST返回
        /// </summary>
        public class GetResponse : PageLoginModel.PostResponse
        {

        }
    }
}