﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 个人中心
    /// </summary>
    public class PageMyInfoModel
    {
        /// <summary>
        /// GET返沪
        /// </summary>
        public class GetResponse
        {
            /// <summary>
            /// 手机号
            /// </summary>
            public string PhoneNum { get; set; } = string.Empty;
            /// <summary>
            /// 昵称
            /// </summary>
            public string NickName { get; set; } = string.Empty;
            /// <summary>
            /// 用户头像|示例：http://37www.com/1.jpg
            /// </summary>
            public ImageUrl HeadImageURL { get; set; }
        }
        /// <summary>
        /// PUT请求
        /// </summary>
        public class PostRequest : ClienterUserLogModel
        {
            /// <summary>
            /// 昵称|不传则不修改
            /// </summary>
            public string NickName { get; set; }
            /// <summary>
            /// 头像|不传则不修改
            /// </summary>
            public string HeadImage { get; set; }
            /// <summary>
            /// 
            /// </summary>
            /// <returns></returns>
            public override string UserLogTitle()
            {
                return "修改资料";
            }
        }
    }
}