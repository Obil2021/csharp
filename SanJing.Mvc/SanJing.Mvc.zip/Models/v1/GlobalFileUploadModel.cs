﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 全局文件上传
    /// </summary>
    public class GlobalFileUploadModel
    {
        /// <summary>
        /// POST返回
        /// </summary>
        public class PostResponse
        {
            /// <summary>
            /// 文件完整URL地址
            /// </summary>
            public string FileUrl { get; set; }
            /// <summary>
            /// 文件相对URL地址
            /// </summary>
            public string FilePath { get; set; }
        }
    }
}