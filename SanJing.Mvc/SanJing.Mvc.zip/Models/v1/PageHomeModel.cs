﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 首页
    /// </summary>
    public class PageHomeModel
    {
        /// <summary>
        /// GET返回
        /// </summary>
        public class GetResponse
        {

            /// <summary>
            /// 记录单词
            /// </summary>
            public Word LastWord { get; set; } = new Word();

            /// <summary>
            /// 单词继续|true表示上次学习的记录，false表示第一次使用
            /// </summary>
            public bool WordContniue { get; set; }

            /// <summary>
            /// 单词所在类型及页码|格式：{类型ID}-{所在页码},例如：1-1
            /// </summary>
            [JsonDefaultValue("1-1")]
            public string WordPosition { get; set; }
            /// <summary>
            /// 测试时间
            /// </summary>
            [JsonDateTimeFormat]
            public DateTime DateTime { get; set; }

            /// <summary>
            /// 单词类型
            /// </summary>
            [JsonDefaultArray]
            public List<WordType> WordTypes { get; set; }

        }
        /// <summary>
        /// 单词类型
        /// </summary>
        public class WordType
        {
            /// <summary>
            /// ID - 单词类型
            /// </summary>
            public int Id { get; set; }
            /// <summary>
            /// 类型名称 - 单词类型
            /// </summary>
            [JsonDefaultString]
            public string Name { get; set; }
            /// <summary>
            /// 单词数量 - 单词类型
            /// </summary>
            public int Count { get; set; }
        }
        /// <summary>
        /// 单词
        /// </summary>
        public class Word
        {
            /// <summary>
            /// 单词文本 - 单词
            /// </summary>
            [JsonDefaultString]
            public string WordText { get; set; }
            /// <summary>
            /// 单词音频地址 - 单词
            /// </summary>
            [JsonDefaultString]
            public string WordVoiceURL { get; set; }
            /// <summary>
            /// 单词下划线 - 单词|true表示有，false表示没有
            /// </summary>
            public bool WordLine { get; set; }
            /// <summary>
            /// 词性及解释 - 单词
            /// </summary>
            [JsonDefaultArray]
            public string[] WordDesc { get; set; }
        }
    }
}