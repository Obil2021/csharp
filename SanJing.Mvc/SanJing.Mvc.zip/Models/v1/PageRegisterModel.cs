﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.v1
{
    /// <summary>
    /// 用户注册
    /// </summary>
    public class PageRegisterModel
    {
        /// <summary>
        /// POST请求
        /// </summary>
        public class PostRequest : PageLoginModel.PostRequest
        {
            /// <summary>
            /// 邀请码
            /// </summary>
            public string InviteCode { get; set; }
        }
        /// <summary>
        /// POST返回
        /// </summary>
        public class PostResponse : PageLoginModel.PostResponse
        {

        }
    }
}