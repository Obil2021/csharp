﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Options
{
    public class HangfireLoginConfig
    {
        public string Login { get; set; }

        public string PasswordClear { get; set; }
    }
}
