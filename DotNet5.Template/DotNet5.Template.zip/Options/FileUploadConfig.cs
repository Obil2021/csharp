﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Options
{
    public class FileUploadConfig
    {
        public bool ResizeEnable { get; set; }
        public string ImageExtension { get; set; }

        public string UnknownExtension { get; set; }

        public bool IsAllow(string extension)
        {
            return ImageExtension.Contains(extension) || UnknownExtension.Contains(extension);
        }
    }
}
