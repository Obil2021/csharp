﻿using Hangfire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.RecurringJobs
{
    public class RecurringJobBox
    {
        private static NLog.Logger logger { get; set; }
        /// <summary>
        /// 请上锁，避免占用太多资源
        /// </summary>
        private static DbContexts.WebApplication7Context context { get; set; }
        public static void Execute()
        {
            logger = NLog.LogManager.GetCurrentClassLogger();
            context = new DbContexts.WebApplication7Context();

            RecurringJob.AddOrUpdate(() => Test(), Cron.Minutely);
        }

        public static void Test()
        {
            lock (context)
            {
                logger.Info("Hello World!");
            }
        }
    }
}
