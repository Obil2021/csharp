﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using $safeprojectname$.OutpotModes;

namespace $safeprojectname$
{
    public class WebApiExceptionFilter : IAsyncExceptionFilter
    {
        private readonly ILogger<WebApiExceptionFilter> logger;
        public WebApiExceptionFilter(ILogger<WebApiExceptionFilter> logger) { this.logger = logger; }

        public Task OnExceptionAsync(ExceptionContext context)
        {
            if (context.ExceptionHandled == false)
            {
                logger.LogError(context.Exception, "未知错误");
                context.Result = new JsonResult(Opt.CreateFailed1500<BaseOpt>());

                context.ExceptionHandled = true;
            }
            return Task.CompletedTask;
        }
    }
}
