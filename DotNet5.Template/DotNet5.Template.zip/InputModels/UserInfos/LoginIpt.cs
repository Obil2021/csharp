﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.InputModels.UserInfos
{
    /// <summary>
    /// 登录输入
    /// </summary>
    public class LoginIpt
    {
        /// <summary>
        /// 账号
        /// </summary>
        [Display(Name = "账号")]
        [Required(ErrorMessage = ErrorMessageConsts.Required)]
        [StringLength(20, MinimumLength = 5, ErrorMessage = ErrorMessageConsts.StringLength)]
        [RegularExpression(RegularExpressionConsts.LetterOrNumber, ErrorMessage = ErrorMessageConsts.RegularLetterOrNumber)]
        public string Account { get; set; }
        /// <summary>
        /// 密码
        /// SHA1
        /// </summary>
        [Display(Name = "密码")]
        [Required(ErrorMessage = ErrorMessageConsts.Required)]
        [StringLength(40, MinimumLength = 40, ErrorMessage = ErrorMessageConsts.StringLength)]
        [RegularExpression(RegularExpressionConsts.LetterOrNumber, ErrorMessage = ErrorMessageConsts.RegularLetterOrNumber)]
        public string Password { get; set; }
    }
}
