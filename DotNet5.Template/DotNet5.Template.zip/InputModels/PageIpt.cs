﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.InputModels
{
    /// <summary>
    /// 分页查询
    /// </summary>
    public class PageIpt
    {
        /// <summary>
        /// 关键词
        /// </summary>
        public string Serach { get; set; }
        /// <summary>
        /// 最大行数
        /// </summary>
        [Range(1, int.MaxValue, ErrorMessage = ErrorMessageConsts.Range)]
        public int? Limit { get; set; }
        /// <summary>
        /// 起始位置
        /// </summary>
        [Range(0, int.MaxValue, ErrorMessage = ErrorMessageConsts.Range)]
        public int? Offset { get; set; }
    }
}
