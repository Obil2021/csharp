﻿using Snowflake.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    /// <summary>
    /// 雪花ID助手
    /// </summary>
    public class SnowflakeHelper
    {
        private readonly static IdWorker idWorker = new IdWorker(1, 1);

        /// <summary>
        /// 获取连续唯一数字ID
        /// </summary>
        /// <returns></returns>
        public static string NextId()
        {
            return idWorker.NextId().ToString();
        }
    }
}
