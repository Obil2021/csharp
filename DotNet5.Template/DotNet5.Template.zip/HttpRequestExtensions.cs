﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public static class HttpRequestExtensions
    {
        /// <summary>
        /// 绝对路径地址转相对路径地址
        /// </summary>
        /// <param name="request"></param>
        /// <param name="path">绝对路径地址</param>
        /// <returns></returns>
        public static string ToRelativePath(this HttpRequest request, string path)
        {
            return path.Replace(new Uri(request.GetDisplayUrl()).GetLeftPart(UriPartial.Authority), string.Empty);
        }

        /// <summary>
        /// 相对路径地址转绝对路径地址
        /// </summary>
        /// <param name="request"></param>
        /// <param name="path">相对路径</param>
        /// <returns></returns>
        public static string ToAbsolutePath(this HttpRequest request, string path)
        {
            return new Uri(request.GetDisplayUrl()).GetLeftPart(UriPartial.Authority) + path;
        }
    }
}
