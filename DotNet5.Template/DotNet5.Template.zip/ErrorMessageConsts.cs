﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ErrorMessageConsts
    {
        public const string Required = "{0} 必填";
        public const string StringLength = "{0} 长度范围[{2},{1}]";
        public const string Range = "{0} 大小范围[{2},{1}]";
        public const string RegularLetter = "{0} 必须由英文字母组成";
        public const string RegularNumber = "{0} 必须由数字组成";
        public const string RegularLetterOrNumber = "{0} 必须由英文字母或数字组成";
        public const string RegularPhone = "{0} 必须是手机号码";
        public const string RegularEmail = "{0} 必须是邮箱地址";
        public const string RegularIDCard = "{0} 必须是身份证号码";
        public const string RegularIPv4 = "{0} 必须是IPv4地址";
    }
    public class RegularExpressionConsts
    {
        public const string Letter = "^[A-Za-z]+$";
        public const string Number = "^[0-9]+$";
        public const string LetterOrNumber = "^[A-Za-z0-9]+$";
        public const string Phone = @"1\d{10}";
        public const string Email = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
        public const string IDCard = @"\d{15}(\d\d[0-9xX])?";
        public const string IPv4 = @"((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)";
    }
}
