﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    /// <summary>
    /// JWT授权
    /// </summary>
    public class JWTTokenHelper
    {
        /// <summary>
        /// 获取TOKEN值
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="id"></param>
        /// <param name="authenticationCodes"></param>
        /// <returns></returns>
        public static string Get(Options.JWTTokenConfig config, string id, params string[] authenticationCodes)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config.SigningKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            //身份
            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, id.ToString()));
            foreach (var code in authenticationCodes)
            {
                claims.Add(new Claim(ClaimTypes.Role, code));
            }

            //令牌
            var expires = DateTime.Now.AddMinutes(config.Expires);
            var token = new JwtSecurityToken(
                issuer: config.Issuer,
                audience: config.Audience,
                claims: claims,
                notBefore: DateTime.Now,
                expires: expires,
                signingCredentials: credentials
                );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
