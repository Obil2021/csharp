﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.OutpotModes.FileInfos
{
    /// <summary>
    /// 上传输出
    /// </summary>
    public class UploadOpt : BaseOpt
    {
        /// <summary>
        /// 文件路劲
        /// </summary>
        public string FilePath { get; set; }
    }
}
