﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.OutpotModes
{
    /// <summary>
    /// 基础输出
    /// </summary>
    public class BaseOpt
    {
        /// <summary>
        /// 状态码
        /// 1200 成功
        /// 1400 已知错误
        /// 1401 未登录
        /// 1403 无权限
        /// 1500 未知错误
        /// </summary>
        [Required]
        public int StatuCode { get; set; }
        /// <summary>
        /// 状态描述
        /// </summary>
        [Required]
        public string StatuMsg { get; set; }
    }
    /// <summary>
    /// 输出
    /// </summary>
    public static class Opt
    {
        /// <summary>
        /// 创建成功实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="action"></param>
        /// <returns></returns>
        public static T CreateSuccessed<T>(Action<T> action = null) where T : BaseOpt, new()
        {
            var opt = new T() { StatuCode = 1200, StatuMsg = "成功" };
            action?.Invoke(opt);
            return opt;
        }
        /// <summary>
        /// 创建位置错误实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T CreateFailed1500<T>() where T : BaseOpt, new()
        {
            return new T() { StatuCode = 1500, StatuMsg = "未知错误" };
        }
        /// <summary>
        /// 创建已知错误实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static T CreateFailed1400<T>(string msg) where T : BaseOpt, new()
        {
            return new T() { StatuCode = 1400, StatuMsg = msg ?? "已知错误" };
        }
        /// <summary>
        /// 创建未登录实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T CreateFailed1401<T>() where T : BaseOpt, new()
        {
            return new T() { StatuCode = 1401, StatuMsg = "未登录" };
        }
        /// <summary>
        /// 创建无权限实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T CreateFailed1403<T>() where T : BaseOpt, new()
        {
            return new T() { StatuCode = 1403, StatuMsg = "无权限" };
        }
        /// <summary>
        /// 创建参数错误实例
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static T CreateFailed1406<T>(string msg) where T : BaseOpt, new()
        {
            return new T() { StatuCode = 1406, StatuMsg = msg ?? "参数错误" };
        }
    }
}
