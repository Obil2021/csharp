﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using $safeprojectname$.JsonConverters;

namespace $safeprojectname$.OutpotModes.UserOperationLogs
{
    /// <summary>
    /// 列表输出
    /// </summary>
    public class ListOpt
    {
        /// <summary>
        /// 操作名称
        /// </summary>
        public string OperationName { get; set; }
        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// IP地址
        /// </summary>
        public string UserIPAddress { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        [JsonConverter(typeof(DateTimeToMinute))]
        public DateTime WriteTime { get; set; }
    }
}
