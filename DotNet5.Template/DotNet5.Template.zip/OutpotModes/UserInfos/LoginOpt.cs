﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.OutpotModes.UserInfos
{
    /// <summary>
    /// 登录输出
    /// </summary>
    public class LoginOpt : BaseOpt
    {
        /// <summary>
        /// 授权TOKEN
        /// </summary>
        public string Token { get; set; } = string.Empty;
        /// <summary>
        /// 权限集合
        /// 引文逗号分割
        /// </summary>
        public string Roles { get; set; } = string.Empty;
    }
}
