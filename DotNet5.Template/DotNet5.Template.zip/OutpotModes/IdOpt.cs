﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.OutpotModes
{
    /// <summary>
    /// 标识输出
    /// </summary>
    public class IdOpt : BaseOpt
    {
        /// <summary>
        /// ID
        /// </summary>
        public string Id { get; set; } = string.Empty;
    }
}
