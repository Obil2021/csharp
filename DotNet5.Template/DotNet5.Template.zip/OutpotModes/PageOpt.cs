﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.OutpotModes
{
    /// <summary>
    /// 分页输出
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PageOpt<T> : BaseOpt
    {
        /// <summary>
        /// 总长度
        /// </summary>
        public int TotalSize { get; set; }
        /// <summary>
        /// 当前数据集
        /// </summary>
        public IEnumerable<T> Rows { get; set; } = new List<T>();
    }
}
