﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace $safeprojectname$.JsonConverters
{
    /// <summary>
    /// 年月日时分 格式化
    /// yyyy-HH-mm HH:mm
    /// </summary>
    public class DateTimeToMinute : DateTimeToSecond
    {
        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("yyyy-MM-dd HH:mm"));
        }
    }
}
