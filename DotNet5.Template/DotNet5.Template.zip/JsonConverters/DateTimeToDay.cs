﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace $safeprojectname$.JsonConverters
{
    /// <summary>
    /// 年月日 格式化
    /// yyyy-HH-dd
    /// </summary>
    public class DateTimeToDay : DateTimeToSecond
    {
        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("yyyy-MM-dd"));
        }

    }
}
