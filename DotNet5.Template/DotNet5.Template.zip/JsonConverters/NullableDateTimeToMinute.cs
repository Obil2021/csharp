﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace $safeprojectname$.JsonConverters
{
    public class NullableDateTimeToMinute : NullableDateTimeToSecond
    {
        public override void Write(Utf8JsonWriter writer, DateTime? value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value?.ToString("yyyy-MM-dd HH:mm") ?? string.Empty);
        }
    }
}
