﻿using System;
using System.Collections.Generic;

#nullable disable

namespace $safeprojectname$.DbContexts
{
    public partial class UserOperationLog
    {
        public string Id { get; set; }
        public string OperationName { get; set; }
        public string UserName { get; set; }
        public string UserIpaddress { get; set; }
        public DateTime CreateTime { get; set; }
    }
}
