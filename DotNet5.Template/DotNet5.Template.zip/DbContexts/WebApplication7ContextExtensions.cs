﻿using Microsoft.AspNetCore.Http;
using System;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using $safeprojectname$.InputModels;
using System.Linq;

namespace $safeprojectname$.DbContexts
{
    public static class WebApplication7ContextExtensions
    {
        public static IQueryable<T> Page<T>(this IOrderedQueryable<T> ordered, PageIpt ipt)
        {
            if (ipt.Offset.HasValue && ipt.Limit.HasValue)
            {
                return ordered.Skip(ipt.Offset.Value).Take(ipt.Limit.Value);
            }
            else
                return ordered;
        }
        public static async Task SaveChangeWithLogAsync(this WebApplication7Context context, string operationName, HttpContext httpContext, string userName = null)
        {
            context.UserOperationLogs.Add(new UserOperationLog()
            {
                Id = SnowflakeHelper.NextId(),
                CreateTime = DateTime.Now,
                OperationName = operationName,
                UserName = userName ?? httpContext.User.Identity.Name ?? "匿名用户",
                UserIpaddress = httpContext.Connection.RemoteIpAddress.ToString(),
            });

            await context.SaveChangesAsync();
        }
    }
}
