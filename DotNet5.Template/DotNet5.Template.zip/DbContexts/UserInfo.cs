﻿using System;
using System.Collections.Generic;

#nullable disable

namespace $safeprojectname$.DbContexts
{
    public partial class UserInfo
    {
        public string Id { get; set; }
        public string Account { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Roles { get; set; }
    }
}
