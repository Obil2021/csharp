using Hangfire;
using Hangfire.Dashboard.BasicAuthorization;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using $safeprojectname$.DbContexts;
using $safeprojectname$.JsonConverters;
using $safeprojectname$.OutpotModes;

namespace $safeprojectname$
{
    public class Startup
    {
        //private readonly string AllowSpecificOrigins = "AllowSpecificOrigins";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            //����
            services.AddCors(options =>
            {
                options.AddPolicy(Configuration.GetSection("AllowSpecificOrigins").Value, builder => builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            });


            services.AddDbContext<WebApplication7Context>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("DbConnectionString"));
            });

            var redisConfig = Configuration.GetSection("RedisCacheConfig").Get<Options.RedisCacheConfig>();
            //redis ����
            services.AddDistributedRedisCache(options =>
            {
                options.Configuration = redisConfig.Configuration;
                options.InstanceName = redisConfig.InstanceName;

            });

            services.AddControllers(options =>
            {
                //ȫ���췵������ģ������
                options.Filters.Add<WebApiExceptionFilter>();

            }).AddJsonOptions(options =>
            {
                //���ڸ�ʽ��
                options.JsonSerializerOptions.Converters.Add(new DateTimeToDay());
                options.JsonSerializerOptions.Converters.Add(new DateTimeToMinute());
                options.JsonSerializerOptions.Converters.Add(new DateTimeToSecond());
                options.JsonSerializerOptions.Converters.Add(new NullableDateTimeToDay());
                options.JsonSerializerOptions.Converters.Add(new NullableDateTimeToMinute());
                options.JsonSerializerOptions.Converters.Add(new NullableDateTimeToSecond());

                //����ʽ��
                options.JsonSerializerOptions.Converters.Add(new DecimalToCent());
                options.JsonSerializerOptions.Converters.Add(new NullableDecimalToCent());
            }).ConfigureApiBehaviorOptions(options =>
                {
                    //����������֤���󷵻�����ģ������
                    options.InvalidModelStateResponseFactory = (context) =>
                    {
                        var error = context.ModelState.SelectMany(q => q.Value.Errors).FirstOrDefault();
                        return new JsonResult(Opt.CreateFailed1406<BaseOpt>(error?.ErrorMessage));
                    };
                });

            //����������֤����
            var jwtConfig = Configuration.GetSection("JWTTokenConfig").Get<Options.JWTTokenConfig>();
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(option =>
            {
                option.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = jwtConfig.Issuer,
                    ValidAudience = jwtConfig.Audience,
                    ValidateIssuer = true,
                    ValidateLifetime = jwtConfig.ValidateLifetime,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtConfig.SigningKey)),
                    ClockSkew = TimeSpan.FromSeconds(0),
                };

                option.Events = new JwtBearerEvents
                {
                    //δ��¼
                    OnChallenge = context =>
                    {
                        //��ֹĬ�ϵķ��ؽ��(������)
                        context.HandleResponse();

                        var result = JsonSerializer.Serialize(Opt.CreateFailed1401<BaseOpt>());
                        context.Response.ContentType = "application/json";
                        context.Response.StatusCode = StatusCodes.Status200OK;
                        context.Response.WriteAsync(result);

                        return Task.CompletedTask;
                    },
                    //��Ȩ��
                    OnForbidden = context =>
                    {
                        var result = JsonSerializer.Serialize(Opt.CreateFailed1403<BaseOpt>());
                        context.Response.ContentType = "application/json";
                        context.Response.StatusCode = StatusCodes.Status200OK;
                        context.Response.WriteAsync(result);

                        return Task.CompletedTask;
                    }
                };
            }); ;

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "$safeprojectname$", Version = "v1" });

                // ��ȡxml�ļ���
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                // ��ȡxml�ļ�·��
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                // ���ӿ�������ע�ͣ�true��ʾ��ʾ������ע��
                if (File.Exists(xmlPath))
                    c.IncludeXmlComments(xmlPath, true);

                //����JWT��֤
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Description = "Authorization��Bearer Token",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });
                //����JWT��֤
                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] { }
                    }
                });
            });

            services.AddHangfire(configuration => configuration
            .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
            .UseSimpleAssemblyNameTypeSerializer()
            .UseRecommendedSerializerSettings()
            .UseSqlServerStorage(Configuration.GetConnectionString("HangfireConnectionString"), new SqlServerStorageOptions
            {
                CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                QueuePollInterval = TimeSpan.Zero,
                UseRecommendedIsolationLevel = true,
                UsePageLocksOnDequeue = true,
                DisableGlobalLocks = true,
                //JobExpirationCheckInterval = TimeSpan.FromHours(1), //- ��ҵ���ڼ�������������ڼ�¼����Ĭ��ֵΪ1Сʱ��
                //CountersAggregateInterval = TimeSpan.FromMinutes(5), //- �ۺϼ������ļ����Ĭ��Ϊ5���ӡ�

            }));

            // Add the processing server as IHostedService
            services.AddHangfireServer();
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "$safeprojectname$ v1"));

            var hangfireLoginConfig = Configuration.GetSection("HangfireLoginConfig").Get<Options.HangfireLoginConfig>();
            // /hangfire
            app.UseHangfireDashboard(options: new DashboardOptions
            {
                Authorization = new[]{new BasicAuthAuthorizationFilter(new BasicAuthAuthorizationFilterOptions
                    {
                        SslRedirect = false,
                        RequireSsl = false,
                        LoginCaseSensitive = false,
                        Users = new[]{ new BasicAuthAuthorizationUser{
                            Login = hangfireLoginConfig.Login,
                            PasswordClear =hangfireLoginConfig.PasswordClear } }
                    }),}
            });

            RecurringJobs.RecurringJobBox.Execute();

            app.UseHttpsRedirection();

            DefaultFilesOptions defaultFilesOptions = new DefaultFilesOptions();
            defaultFilesOptions.DefaultFileNames.Clear();
            defaultFilesOptions.DefaultFileNames.Add("index.html");
            app.UseDefaultFiles(defaultFilesOptions);

            app.UseStaticFiles();

            app.UseRouting();

            app.UseCors(Configuration.GetSection("AllowSpecificOrigins").Value);

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
