﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.Options;
using $safeprojectname$.OutpotModes;
using $safeprojectname$.OutpotModes.FileInfos;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 文件相关
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class FileInfosController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly IWebHostEnvironment webHostEnvironment;
        public FileInfosController(
            IWebHostEnvironment webHostEnvironment,
            IConfiguration configuration)
        {
            this.webHostEnvironment = webHostEnvironment;
            this.configuration = configuration;
        }
        [HttpPost]
        [Route("upload")]
        public async Task<UploadOpt> UploadAsync(IFormFile ipt)
        {
            if (ipt == null)
                return Opt.CreateFailed1406<UploadOpt>("请上传文件");

            //文件类型验证
            var ext = Path.GetExtension(ipt.FileName).ToLower();
            var exts = configuration.GetSection("FileUploadConfig").Get<FileUploadConfig>();
            if (!exts.IsAllow(ext))
                return Opt.CreateFailed1406<UploadOpt>($"仅支持以下文件类型：{exts.ImageExtension}|{exts.UnknownExtension}");

            //MD5

            using var md5 = new MD5CryptoServiceProvider();
            byte[] retVal = await md5.ComputeHashAsync(ipt.OpenReadStream());

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < retVal.Length; i++)
            {
                sb.Append(retVal[i].ToString("x2"));
            }
            string md5Value = sb.ToString();


            var path = @$"/uploads/{md5Value}/{ipt.FileName}";

            var fileName = webHostEnvironment.WebRootPath + path;
            //文件夹
            var dir = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            var filePath = Request.ToAbsolutePath(path);
            if (!System.IO.File.Exists(fileName))
            {
                if (exts.ResizeEnable && exts.ImageExtension.Contains(ext))
                {
                    //压缩图片并保存
                    ResizeImageAndSave(ipt.OpenReadStream(), fileName);
                }
                else
                {
                    using var stream = new FileStream(fileName, FileMode.Create);
                    await ipt.CopyToAsync(stream);
                }
            }

            return Opt.CreateSuccessed<UploadOpt>(opt => { opt.FilePath = filePath; });
        }
        /// <summary>
        /// 压缩图片并保存
        /// 1024*768
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="filename"></param>
        private void ResizeImageAndSave(Stream stream, string filename)
        {
            //可以直接从流里边得到图片,这样就可以不先存储一份了
            using Image iSource = Image.FromStream(stream);

            ImageFormat tFormat = iSource.RawFormat;

            if (iSource.Width <= 1024 && iSource.Height <= 760)
            {
                iSource.Save(filename, tFormat);
                return;
            }

            int newWidth = iSource.Width;
            int newHeigth = iSource.Height;

            if (newWidth > 1024)
            {
                newHeigth = newHeigth * 1024 / newWidth;
                newWidth = 1024;
            }

            if (newHeigth > 768)
            {
                newWidth = newWidth * 768 / newHeigth;
                newHeigth = 768;
            }

            using Bitmap ob = new Bitmap(newWidth, newHeigth);


            using Graphics g = Graphics.FromImage(ob);

            g.CompositingQuality = CompositingQuality.HighQuality;
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            g.DrawImage(iSource, new Rectangle(0, 0, newWidth, newHeigth), 0, 0, iSource.Width, iSource.Height, GraphicsUnit.Pixel);
            ob.Save(filename, tFormat);


        }
    }
}
