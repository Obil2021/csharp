﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using $safeprojectname$.DbContexts;
using $safeprojectname$.InputModels;
using $safeprojectname$.InputModels.UserOperationLogs;
using $safeprojectname$.OutpotModes;
using $safeprojectname$.OutpotModes.UserOperationLogs;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 操作日志相关
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserOperationLogsController : ControllerBase
    {
        private readonly WebApplication7Context context;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public UserOperationLogsController(WebApplication7Context context)
        {
            this.context = context;
        }
        /// <summary>
        /// 列表查询
        /// </summary>
        /// <param name="ipt"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("list")]
        [Authorize(Roles = "A001")]
        public async Task<PageOpt<ListOpt>> ListAsync([FromQuery] ListIpt ipt)
        {
            var sql = context.UserOperationLogs.AsNoTracking()
                .Where(q => ipt.Serach == null
                || q.OperationName.Contains(ipt.Serach)
                || q.UserName.Contains(ipt.Serach)
                || q.UserIpaddress.Contains(ipt.Serach));

            var total = await sql.CountAsync();

            var rows = await sql.OrderByDescending(q => q.CreateTime).Page(ipt).Select(q => new ListOpt()
            {
                WriteTime = q.CreateTime,
                OperationName = q.OperationName,
                UserIPAddress = q.UserIpaddress,
                UserName = q.UserName,
            }).ToListAsync();

            return Opt.CreateSuccessed<PageOpt<ListOpt>>(opt =>
            {
                opt.TotalSize = total;
                opt.Rows = rows;
            });
        }
    }
}
