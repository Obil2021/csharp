﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using $safeprojectname$.DbContexts;
using $safeprojectname$.InputModels;
using $safeprojectname$.InputModels.UserInfos;
using $safeprojectname$.Options;
using $safeprojectname$.OutpotModes;
using $safeprojectname$.OutpotModes.UserInfos;

namespace $safeprojectname$.Controllers
{
    /// <summary>
    /// 账户相关
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfosController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly ILogger logger;
        private readonly WebApplication7Context context;
        private readonly IDistributedCache cache;
        public UserInfosController(
            IConfiguration configuration,
            WebApplication7Context context,
            ILogger<UserInfosController> logger,
            IDistributedCache cache)
        {
            this.configuration = configuration;
            this.logger = logger;
            this.context = context;
            this.cache = cache;
        }
        /// <summary>
        /// 登录授权
        /// </summary>
        /// <param name="ipt"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("login")]
        public async Task<LoginOpt> LoginAsync(LoginIpt ipt)
        {
            var userInfo = await context.UserInfos.AsNoTracking()
                    .FirstOrDefaultAsync(q => q.Account == ipt.Account && q.Password == ipt.Password);

            if (userInfo == null)
                return Opt.CreateFailed1406<LoginOpt>("账号或密码不正确");
            var token = JWTTokenHelper.Get(configuration.GetSection("JWTTokenConfig")
                .Get<JWTTokenConfig>(), userInfo.Id, userInfo.Roles.Split(","));

            await context.SaveChangeWithLogAsync("用户登录", HttpContext, userInfo.Name);

            return Opt.CreateSuccessed<LoginOpt>(opt => { opt.Token = token; opt.Roles = userInfo.Roles; });
        }
        /// <summary>
        /// 授权测试
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("login/test")]
        [Authorize(Roles = "A001,A002")]
        public BaseOpt LoginTest()
        {
            return Opt.CreateSuccessed<BaseOpt>();
        }
        /// <summary>
        /// 缓存、ID测试
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("cache/test")]
        public IdOpt CacheTest()
        {

            DistributedCacheEntryOptions options = new DistributedCacheEntryOptions();
            //设置绝对过期时间 两种写法
            options.AbsoluteExpiration = DateTime.Now.AddMinutes(30);

            var newid = SnowflakeHelper.NextId();

            //写入
            cache.SetString("NewId", newid, options);

            //读取
            var v = cache.GetString("NewId");


            return Opt.CreateSuccessed<IdOpt>(opt => { opt.Id = newid; });
        }
    }
}
