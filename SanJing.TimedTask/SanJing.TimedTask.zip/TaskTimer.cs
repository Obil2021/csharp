﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace $safeprojectname$
{
    /// <summary>
    /// 任务类，继承此类即可
    /// </summary>
    public abstract class TaskTimer
    {
        private Timer Timer = new Timer();
        public TextBox TextBox { get; set; }
        private BackgroundWorker BackgroundWorker { get; set; } = new BackgroundWorker();
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="second">间隔时间（秒）</param>
        /// <param name="textBox">日志输出控件</param>
        public void Set(int second, TextBox textBox)
        {
            TextBox = textBox;
            Timer.Interval = second * 1000;
            Timer.Tick += Timer_Tick;
            BackgroundWorker.DoWork += BackgroundWorker_DoWork;
            BackgroundWorker.ProgressChanged += BackgroundWorker_ProgressChanged;
            BackgroundWorker.WorkerReportsProgress = true;
        }

        private void BackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            WriteLogToText(e.UserState.ToString());
        }

        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                Do();
                WriteLog("Success");
            }
            catch (Exception ex)
            {
                WriteLog($"{ex.Message}");
            }
        }

        /// <summary>
        /// 任务代码，请重写此方法
        /// </summary>
        public abstract void Do();
        private void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (BackgroundWorker.IsBusy)
                    return;
                BackgroundWorker.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                WriteLogToText($"{ex.Message}");
            }
        }
        /// <summary>
        /// 开始任务
        /// </summary>
        public void Run()
        {
            Timer.Start();
        }
        /// <summary>
        /// 输出日志
        /// </summary>
        /// <param name="log">日志内容</param>
        public void WriteLog(string log)
        {
            if (BackgroundWorker.IsBusy)
                BackgroundWorker.ReportProgress(1, log);
        }

        private void WriteLogToText(string log)
        {
            if (TextBox.Lines.Length > 10000)
            {
                TextBox.Clear();
            }
            var txt = log.Replace(Environment.NewLine, " ");
            TextBox.AppendText($"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} {GetType().Name}:{txt}{Environment.NewLine}");
            TextBox.SelectionStart = TextBox.Text.Length - 1;
        }
        /// <summary>
        /// 关闭任务
        /// </summary>
        public void Close()
        {
            Timer.Stop();
        }
    }
}
