﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $safeprojectname$
{
    /// <summary>
    /// 任务类，继承此类即可
    /// </summary>
    public abstract class TaskTimer
    {
        private Timer Timer = new Timer();
        public TextBox TextBox { get; set; }
        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="second">间隔时间（秒）</param>
        /// <param name="textBox">日志输出控件</param>
        public void Set(int second,TextBox textBox)
        {
            TextBox = textBox;
            Timer.Interval = second * 1000;
            Timer.Tick += Timer_Tick;
        }
        /// <summary>
        /// 任务代码，请重写此方法
        /// </summary>
        public abstract void Do();
        private void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                Do();
                WriteLog("SUCCESS");
            }
            catch (Exception ex)
            {
                WriteLog($"{ex.Message}");
            }
        }
        /// <summary>
        /// 开始任务
        /// </summary>
        public void Run()
        {
            Timer.Start();
        }
        /// <summary>
        /// 输出日志
        /// </summary>
        /// <param name="log">日志内容</param>
        public void WriteLog(string log)
        {
            if (TextBox.Lines.Length > 10000)
            {
                TextBox.Clear();
            }
            var txt = log.Replace(Environment.NewLine, " ");
            TextBox.AppendText($"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} {GetType().Name}:{txt}{Environment.NewLine}");
            TextBox.SelectionStart = TextBox.Text.Length - 1;
        }
        /// <summary>
        /// 关闭任务
        /// </summary>
        public void Close()
        {
            Timer.Stop();
        }
    }
}
