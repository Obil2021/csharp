﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    /// <summary>
    /// 测试任务
    /// </summary>
    public class TaskTimer_Test : TaskTimer
    {
        public override void Do()
        {
            WriteLog("test");
        }
    }
}
