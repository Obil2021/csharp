﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public class TaskTimed
    {
        private static List<TaskTimer> taskTimers = new List<TaskTimer>();
        /// <summary>
        /// 注册任务
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="second">时间间隔（秒）</param>
        /// <param name="textBox">日志输出控件</param>
        public static void Create<T>(int second, TextBox textBox) where T : TaskTimer, new()
        {
            var task = new T();
            task.Set(second, textBox);
            task.Run();

            taskTimers.Add(task);
        }
        /// <summary>
        /// 关闭所有任务
        /// </summary>
        public static void CloseAll()
        {
            foreach (var item in taskTimers)
            {
                item.Close();
            }
        }
    }
}
